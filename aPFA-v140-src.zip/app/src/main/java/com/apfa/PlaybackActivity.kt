package com.apfa

import android.app.Activity
import android.app.ActionBar
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.os.Environment
import android.provider.OpenableColumns
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream

/**
 * Loading screen -> GL playback surface. The HUD (Time + FPS) is rendered
 * directly by the native engine every frame, like PFA's RenderText(). The
 * seek bar is polled from the UI thread at 16 ms (display rate) — it's a
 * UI control, not a timing-critical element, so this is fine.
 */
class PlaybackActivity : Activity(), SurfaceHolder.Callback {

    companion object {
        /**
         * The real filesystem path behind a picked URI, or null.
         *
         * Deliberately does NOT use DocumentsContract: that class is API 19+ and
         * this app's floor is API 10, where merely naming a missing class inside a
         * method body can upset Dalvik's verifier. Everything here is Uri string
         * work, which is API 1. Shared with MainActivity, which uses it to tell
         * whether a saved soundfont is still reachable once its grant is gone.
         */
        fun resolveLocalPath(uri: Uri): String? {
            if ("file".equals(uri.scheme, ignoreCase = true)) return uri.path
            if (!"content".equals(uri.scheme, ignoreCase = true)) return null
            val id = documentId(uri) ?: return null
            // ExternalStorageProvider ids read "primary:Download/x.sfz", or
            // "1A2B-3C4D:Fonts/x.sfz" on a removable volume.
            val colon = id.indexOf(':')
            if (colon < 0) return null
            val volume = id.substring(0, colon)
            val rel    = id.substring(colon + 1)
            if (rel.isEmpty()) return null
            return if (volume.equals("primary", ignoreCase = true))
                File(Environment.getExternalStorageDirectory(), rel).absolutePath
            else
                File(File("/storage", volume), rel).absolutePath
        }

        /** The decoded document id of a SAF URI (.../document/<id>). */
        private fun documentId(uri: Uri): String? {
            val segs = uri.pathSegments ?: return null
            val i = segs.lastIndexOf("document")
            return if (i >= 0 && i + 1 < segs.size) segs[i + 1] else null
        }

        /**
         * Delete the per-playback copies in [cacheDir]: input.mid, copied
         * .sf2/.sf3 fonts and the rebuilt sfz/ tree. Every Play re-copies them,
         * so keeping them saves nothing and they piled up to hundreds of MB.
         * apfa_lastload is left alone: it has to outlive a killed process.
         * Unlinking a file the engine still has open is safe on Linux.
         */
        fun clearCopies(cacheDir: File) {
            File(cacheDir, "input.mid").delete()
            File(cacheDir, "sfz").deleteRecursively()
            cacheDir.listFiles()?.forEach { f ->
                val n = f.name.lowercase()
                if (f.isFile && (n.endsWith(".sf2") || n.endsWith(".sf3"))) f.delete()
            }
        }

        // The newest playback's number. The engine (g_engine in native-lib.cpp)
        // and the cache copies are process-wide, but a finishing playback can be
        // stopped and destroyed AFTER the next one has been created (Android
        // destroys the old activity once the new screen is idle). Those late
        // calls would stop and free the NEW engine mid-load, and delete the
        // MIDI copy it is reading, so only the newest playback makes them.
        private var newestSession = 0

        init {
            System.loadLibrary("bass")
            System.loadLibrary("bassmidi")
            System.loadLibrary("apfa")
        }
        const val EXTRA_MIDI     = "midi"
        const val EXTRA_SF       = "sf"
        const val EXTRA_VOICES   = "voices"
        const val EXTRA_SPEED    = "speed"
        const val EXTRA_CPU_MASK = "cpuMask"
        const val EXTRA_BG_COLOR = "bgColor"
        const val EXTRA_BG_IMAGE = "bgImage"
        const val EXTRA_LEGACY   = "legacyRenderer"   // ES2 "Legacy Renderer (GLES 2.0)"
        const val EXTRA_STREAM   = "diskStreaming"    // allow the chunked pagefile sort
                                                      // (key name kept for settings compat)
        const val EXTRA_SD_POOL  = "sdPagefile"       // put the pagefile on the SD card
        const val EXTRA_SYNTH_VOLUME = "synthVolume"  // BASSMIDI output level, 0..100
        const val EXTRA_SAMPLE_RATE  = "sampleRate"   // BASSMIDI render rate, Hz
        const val EXTRA_RES_W    = "resW"             // render resolution; 0 = native
        const val EXTRA_RES_H    = "resH"
        const val EXTRA_DARK     = "dark"             // setup screen's Light/Dark, for dialogs
        const val EXTRA_VERBOSE  = "verboseLoading"   // stage + log line under the %
        const val EXTRA_START_FULLSCREEN = "startFullscreen"  // action bar hidden at start
        const val EXTRA_PAUSE_ON_LOAD    = "pauseOnLoad"      // start paused on the pre-roll
        // Cap the decoded background so it fits comfortably in a GL texture on
        // budget devices; it's stretched anyway, so detail loss is fine.
        private const val BG_MAX_DIM = 1280

        // Ceilings for rebuilding an SFZ instrument in the cache (below). An
        // .sfz can name a whole sample library; these stop a mis-pick filling
        // the phone. Hit either and the bundle stops and says so.
        private const val SFZ_MAX_FILES = 4096
        private const val SFZ_MAX_BYTES = 512L * 1024 * 1024
        private const val SFZ_MAX_TEXT  = 8L * 1024 * 1024

        // opcode=value, several to a line. Deliberately not anchored: the value
        // of the PREVIOUS opcode is whatever sits between two of these matches.
        private val SFZ_OPCODE  = Regex("([A-Za-z_][A-Za-z0-9_]*)\\s*=")
        private val SFZ_INCLUDE = Regex("^\\s*#include\\s+\"([^\"]+)\"")
        // SFZ v2 / ARIA macros: "#define $EXT flac", used later as "...-PP.$EXT".
        private val SFZ_DEFINE  = Regex("^\\s*#define\\s+(\\$[A-Za-z0-9_]+)\\s+(\\S+)")
    }

    // poolDir: where the streaming pagefile goes. "" = next to the MIDI, in the
    // app cache dir; otherwise the app's cache dir on the SD card.
    private external fun nativeLoad(midiPath: String, sfPath: String,
                                    voiceCount: Int, noteSpeed: Float,
                                    cpuMask: Long, legacyRenderer: Boolean,
                                    allowChunked: Boolean,
                                    poolDir: String,
                                    force: Boolean,
                                    sampleRate: Int, synthVolume: Float): Boolean
    // The memory gate's numbers from the last nativeLoad, for the "load anyway"
    // prompt: what the load needs held in memory, and what the device can spare.
    private external fun nativeGetGateNeedBytes(): Long
    private external fun nativeGetGateRoomBytes(): Long
    // Why the last nativeLoad returned false: 0 generic, 1 needs Chunked Disk
    // Paging (Advanced Settings), 2 not enough free storage for the pagefile,
    // 3 pagefile past the volume's file-size limit (a FAT32 card stops at 4 GB),
    // 4 the pool's address-space reservation failed (32-bit OS), 5 streaming was
    // unavailable and the in-RAM parse was already predicted not to fit.
    private external fun nativeGetLoadError(): Int
    private external fun nativeGetLoadProgress(): Float
    private external fun nativeGetNoteCount(): Long
    // "stage\nlast log line" while nativeLoad runs (UTF-8 bytes).
    private external fun nativeGetLoadStatus(): ByteArray?
    private external fun nativeGetMemoryBytes(): Long
    private external fun nativeGetStreamedBytes(): Long
    private external fun nativeStart(surface: Surface)
    private external fun nativeStop()
    private external fun nativeRelease()
    private external fun nativeSurfaceChanged(w: Int, h: Int)
    private external fun nativePause()
    private external fun nativeResume()
    private external fun nativeSeek(micros: Long)
    private external fun nativeIsPlaying(): Boolean
    private external fun nativeGetStartError(): Int
    private external fun nativeGetTimeMicros(): Long
    private external fun nativeGetTotalMicros(): Long
    private external fun nativeGetMinMicros(): Long
    private external fun nativeGetMaxMicros(): Long
    private external fun nativeGetFps(): Float
    private external fun nativeSetBgColor(bgrColor: Int)
    private external fun nativeSetBgImage(pixels: IntArray, w: Int, h: Int)

    private val ui = Handler(Looper.getMainLooper())

    private lateinit var loadingText: TextView
    private lateinit var loadingDetail: TextView
    private lateinit var loadingOverlay: TextView

    private var session = 0
    // False once a newer playback exists: see newestSession.
    private val newest get() = session == newestSession

    @Volatile private var copying = true
    // What the copy stage is doing, and how far it has got, for the verbose
    // line — the native status only exists once nativeLoad is running.
    @Volatile private var copyLabel = ""
    @Volatile private var copiedBytes = 0L
    private var stopped     = false
    private var infoLine    = ""
    private var paused      = false
    private var userSeeking = false
    private lateinit var pauseButton: Button
    private lateinit var seekBar: SeekBar
    private var uiHidden     = false
    private var lastTapTime  = 0L
    private var holdFired    = false
    private var dark         = false
    private var verbose      = false
    private var startFullscreen = false

    // getActionBar() is API 11+; on Gingerbread the method does not exist and
    // calling it throws NoSuchMethodError (an Error — catch(Exception) misses it).
    // Below 11 we never touch it: playback runs bare on the fullscreen surface,
    // no seek bar, hold-to-pause still works.
    private val hasActionBar = Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        session = ++newestSession
        // Pre-Honeycomb the default theme has a title bar, and FLAG_FULLSCREEN only
        // takes the status bar. Drop it so playback is truly fullscreen. Never do
        // this at 11+ — it would remove the action bar we host the transport in.
        if (!hasActionBar) requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val midiUri = intent.getStringExtra(EXTRA_MIDI)
        if (midiUri == null) { finish(); return }
        val sfUri      = intent.getStringExtra(EXTRA_SF)
        val voiceCount = intent.getIntExtra(EXTRA_VOICES, 250)
        val noteSpeed  = intent.getFloatExtra(EXTRA_SPEED, 0.05f)
        val cpuMask    = intent.getLongExtra(EXTRA_CPU_MASK, 0L)
        val bgColor    = intent.getIntExtra(EXTRA_BG_COLOR, 0x00464646)
        val bgImage    = intent.getStringExtra(EXTRA_BG_IMAGE)
        val legacy     = intent.getBooleanExtra(EXTRA_LEGACY, false)
        val chunked    = intent.getBooleanExtra(EXTRA_STREAM, false)
        val sdPagefile = intent.getBooleanExtra(EXTRA_SD_POOL, false)
        val synthVol   = intent.getIntExtra(EXTRA_SYNTH_VOLUME, 100).coerceIn(0, 100) / 100f
        val sampleRate = intent.getIntExtra(EXTRA_SAMPLE_RATE, 44100)
        dark           = intent.getBooleanExtra(EXTRA_DARK, false)
        verbose        = intent.getBooleanExtra(EXTRA_VERBOSE, false)
        startFullscreen = intent.getBooleanExtra(EXTRA_START_FULLSCREEN, false)
        val pauseOnLoad = intent.getBooleanExtra(EXTRA_PAUSE_ON_LOAD, false)

        showLoadingScreen()

        Thread {
            copyLabel = "Copying the MIDI into app storage"
            val midiPath = copyToCache(midiUri, "input.mid")
            copyLabel = "Preparing the soundfont"
            val sfPath   = if (sfUri.isNullOrEmpty()) "" else prepareSoundfont(sfUri)
            copying = false
            if (midiPath == null) {
                ui.post { fail("Could not read the MIDI file") }
                return@Thread
            }
            // No soundfont means no sound. Say it once, up front, so a silent
            // playback reads as a choice rather than as a broken load. Covers
            // both "none was picked" and "the copy failed" — sfPath is what
            // nativeLoad actually gets either way.
            if (sfPath.isEmpty()) {
                ui.post {
                    Toast.makeText(this,
                        "You are going to play this MIDI without a soundfont!",
                        Toast.LENGTH_LONG).show()
                }
            }
            // Re-checked here, on the loading thread, rather than trusted from
            // the saved setting: this is the point of use, and the card can be
            // gone (or the whole option invalid) since the box was ticked.
            // Anything wrong = internal storage, which is where the pagefile
            // went before this setting existed — say so and load anyway.
            var poolDir = ""
            if (sdPagefile) {
                val why = SdCard.unavailableReason(this)
                val sd  = if (why == null) SdCard.cacheDir(this) else null
                if (sd != null) {
                    poolDir = sd.absolutePath
                } else {
                    Log.w("aPFA", "SD pagefile requested but unavailable: $why")
                    ui.post {
                        Toast.makeText(this,
                            "Using internal storage for the pagefile — " +
                            (why ?: "no SD card detected."),
                            Toast.LENGTH_LONG).show()
                    }
                }
            }
            // A local function so "Load anyway" can re-enter it with force = true
            // WITHOUT redoing copyToCache — the cache copy is already done and on
            // a MIDI this size it is minutes of the wall clock by itself.
            fun attempt(force: Boolean) {
            val ok = nativeLoad(midiPath, sfPath, voiceCount, noteSpeed, cpuMask, legacy,
                                chunked, poolDir, force, sampleRate, synthVol)
            // Decode + upload the background image off the UI thread (it can be big).
            // The engine just stashes it; the render thread does the GL upload.
            if (ok && !bgImage.isNullOrEmpty()) applyBgImage(bgImage)
            ui.post {
                if (ok) {
                    nativeSetBgColor(bgColor)
                    val mb = nativeGetMemoryBytes() / 1048576.0
                    // Nonzero only when the load went through the streaming
                    // pool — then the line shows how much pool was pagefiled.
                    val streamedMb = nativeGetStreamedBytes() / 1048576.0
                    infoLine = if (streamedMb > 0)
                        "%,d notes  -  %.1f MB RAM (%.1f MB streamed)"
                            .format(nativeGetNoteCount(), mb, streamedMb)
                    else
                        "%,d notes  -  %.1f MB".format(nativeGetNoteCount(), mb)
                    Log.i("aPFA", infoLine)
                    // Paused before the engine thread exists, so the first
                    // frame it draws is already paused on the pre-roll.
                    if (pauseOnLoad && !paused) { paused = true; nativePause() }
                    showPlaybackScreen()
                } else {
                    when (nativeGetLoadError()) {
                        1 -> fail("This Black MIDI likely needs Chunked Disk Paging, " +
                                  "please enable it in Advanced Settings > Main.")
                        2 -> fail("Not enough space on disk to load this MIDI! " +
                                  "Please free up space!" +
                                  // Only suggest the card where it is a real option.
                                  if (!sdPagefile && SdCard.unavailableReason(this) == null)
                                      " You can also set Pagefile Location to SD Card " +
                                      "in Advanced Settings > Main."
                                  else "")
                        3 -> fail("This MIDI's pagefile is over the 4 GB per-file limit of " +
                                  "a FAT32 card. Reformat the card as exFAT to use it for " +
                                  "MIDIs this big.")
                        4, 5 -> fail("aPFA has encountered a paging error where the " +
                                  "amount alloted is too large for your RAM! Please " +
                                  "report this issue to Starzainia so he can fix this bug!")
                        6 -> fail("This MIDI is too big for this phone's RAM. Chunked " +
                                  "Disk Streaming moves the sort to disk, but the last " +
                                  "stage of the load still has to hold a note index in " +
                                  "RAM that cannot be streamed, and this MIDI's index is " +
                                  "bigger than this phone's share of memory. Free storage " +
                                  "doesn't help — a phone with more RAM will load it.")
                        // Not a refusal — an informed choice. See confirmOverload.
                        7 -> confirmOverload { Thread { attempt(true) }.start() }
                        else -> fail("Could not parse the MIDI file")
                    }
                }
            }
            }
            attempt(false)
        }.start()
    }

    // ---- loading screen ----

    private fun showLoadingScreen() {
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(18, 18, 24))
            setPadding(dp(32), 0, dp(32), 0)
        }
        loadingText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            gravity = Gravity.CENTER
            text = "Loading..."
        }
        column.addView(loadingText)
        // Verbose Loading Details: what the load is doing, in smaller text
        // under the percentage. Stage on the first line, the latest log line
        // (the gate's and the streamer's decisions) on the second.
        loadingDetail = TextView(this).apply {
            setTextColor(Color.rgb(170, 170, 180))
            textSize = 12f
            gravity = Gravity.CENTER
            maxLines = 4
            visibility = if (verbose) View.VISIBLE else View.GONE
        }
        column.addView(loadingDetail, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(8)
        })
        setContentView(column)
        ui.post(loadingPoll)
    }

    private val loadingPoll = object : Runnable {
        override fun run() {
            if (stopped) return
            loadingText.text = if (copying) "Copying file..."
                else "Loading MIDI...  %d%%".format((nativeGetLoadProgress() * 100).toInt())
            if (verbose) loadingDetail.text = loadDetail()
            ui.postDelayed(this, 120)
        }
    }

    private fun loadDetail(): String {
        if (copying) {
            val n = copiedBytes
            return if (n > 0) "%s — %.1f MB".format(copyLabel, n / 1048576.0) else copyLabel
        }
        val raw = nativeGetLoadStatus() ?: return ""
        return String(raw, Charsets.UTF_8).trim()
    }

    // A load that cannot proceed has something to SAY — which storage ran out,
    // which setting to turn on, that the MIDI needs a 64-bit Android. As a
    // Toast fired while the activity was already finishing, that message
    // flashed past over a progress bar frozen mid-count and the whole thing
    // read as a crash (it was mistaken for one twice while testing the 32-bit
    // address-space limit). A dialog that waits to be dismissed says the same
    // thing where it can actually be read, and only then drops back to setup.
    // The memory gate is advisory, not a veto. It knows what the load must keep
    // in memory and what the device can spare; it does NOT know that the user is
    // willing to lose ten minutes and their launcher to find out. So it asks.
    //
    // The cost is real and the prompt says it plainly: measured on an S22 Ultra,
    // a load far enough over ran nine minutes, wrote ~40 GB, and was killed by
    // Android after lmkd had already reaped the launcher, the keyboard and 25
    // other processes. Cancel is the default for that reason, not to discourage.
    private fun confirmOverload(onProceed: () -> Unit) {
        if (isFinishing) return
        val needMb = nativeGetGateNeedBytes() / 1048576.0
        val roomMb = nativeGetGateRoomBytes() / 1048576.0
        val detail = if (needMb > 0 && roomMb > 0)
            "It needs about %,.0f MB kept in memory, and this phone can spare about %,.0f MB right now.".format(needMb, roomMb)
        else
            "It needs more memory than this phone can spare right now."
        try {
            UiTheme.dialogBuilder(this, dark)
                .setTitle("This MIDI may not fit")
                .setMessage(detail + "\n\n" +
                    "You can try anyway. If it does not fit, the load may run for " +
                    "several minutes and write tens of GB to storage before Android " +
                    "kills it — and it may close your launcher, keyboard and other " +
                    "apps on the way. Closing other apps first gives it a better chance.")
                .setCancelable(false)
                .setNegativeButton("Cancel") { _, _ -> finish() }
                .setPositiveButton("Load anyway") { _, _ ->
                    showLoadingScreen()
                    onProceed()
                }
                .show()
        } catch (e: Exception) {
            // No window to attach to — same fallback shape as fail().
            fail(detail)
        }
    }

    private fun fail(msg: String) {
        if (isFinishing) return
        try {
            UiTheme.dialogBuilder(this, dark)
                .setTitle("Can't load this MIDI")
                .setMessage(msg)
                .setCancelable(false)
                .setPositiveButton("OK") { _, _ -> finish() }
                .show()
        } catch (e: Exception) {
            // No window to attach to (activity already going away) — say it the
            // old way rather than not at all.
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            finish()
        }
    }

    // ---- playback screen ----

    private fun showPlaybackScreen() {
        ui.removeCallbacks(loadingPoll)
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)   // the bars around a non-native resolution

        // GFX > Resolution. setFixedSize makes the surface's buffers exactly
        // resW x resH, so EGL, the renderer and the HUD all see that size —
        // and the display hardware scales the result onto the panel. The view
        // is fitted to the resolution's own shape, so a 5:3 800x480 shows as
        // 5:3 with bars either side instead of stretched across a 20:9 screen.
        val resW = intent.getIntExtra(EXTRA_RES_W, 0)
        val resH = intent.getIntExtra(EXTRA_RES_H, 0)
        val fixed = resW > 0 && resH > 0
        val surface = if (fixed) FittedSurfaceView(this, resW, resH) else SurfaceView(this)
        if (fixed) surface.holder.setFixedSize(resW, resH)
        surface.holder.addCallback(this)
        root.addView(surface, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            Gravity.CENTER))

        // Hold (400 ms): pause/resume immediately when threshold is reached.
        // Double-tap (two short taps < 300 ms apart): hide/show the action bar.
        val holdRunnable = Runnable {
            holdFired = true
            togglePause()
        }
        // On the root, not the surface, so the bars beside a fitted surface
        // take the gestures too. The surface isn't clickable, so its touches
        // fall through to here.
        root.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    holdFired = false
                    ui.postDelayed(holdRunnable, 400L)
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    ui.removeCallbacks(holdRunnable)
                    if (!holdFired) {
                        // Short tap — check for double-tap
                        val now = System.currentTimeMillis()
                        if (now - lastTapTime < 300L) toggleUi()
                        lastTapTime = now
                    }
                }
            }
            true
        }

        // Action bar: seek bar + pause button.
        // Time and FPS are drawn by the GL renderer every frame — no TextView needed.
        if (hasActionBar) actionBar?.let { ab ->
            val bar = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val title = TextView(this).apply {
                text = "aPFA"
                setTextColor(Color.WHITE)
                textSize = 18f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            }
            bar.addView(title, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { rightMargin = dp(16) })
            seekBar = SeekBar(this).apply {
                max = 1000
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {}
                    override fun onStartTrackingTouch(s: SeekBar?) { userSeeking = true }
                    override fun onStopTrackingTouch(s: SeekBar?) {
                        // Map the slider across [min, max] = PFA's
                        // [GetMinTime, GetMaxTime], so the far left seeks into the
                        // -3s pre-roll (shows "-00:03"), like stock PFA:
                        // JumpTo(llFirstTime + (llLastTime-llFirstTime)*p/1000).
                        val minU = nativeGetMinMicros()
                        val maxU = nativeGetMaxMicros()
                        if (maxU > minU)
                            nativeSeek(minU + (maxU - minU) * (s?.progress ?: 0).toLong() / 1000L)
                        userSeeking = false
                    }
                })
            }
            bar.addView(seekBar, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            pauseButton = Button(this).apply {
                text = if (paused) "▶" else "❚❚"      // Always Pause Player on Load
                setOnClickListener { togglePause() }
            }
            bar.addView(pauseButton)
            ab.setDisplayShowTitleEnabled(false)
            ab.setDisplayShowCustomEnabled(true)
            ab.setCustomView(bar, ActionBar.LayoutParams(
                ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.MATCH_PARENT))
            // Always Start Full Screen: begin as if double-tapped once; a
            // double-tap still brings the bar back.
            if (startFullscreen) {
                uiHidden = true
                ab.hide()
            }
        }

        loadingOverlay = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(18, 18, 24))
            text = "Starting...\n$infoLine"
        }
        root.addView(loadingOverlay, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        setContentView(root)
        // Poll seek bar at ~display rate. This is only a UI control, not timing-critical.
        ui.post(seekPoll)
    }

    // Seek bar poll — 16 ms matches display refresh. Only updates the seek bar
    // thumb position; Time and FPS are rendered by GL, not here.
    private val seekPoll = object : Runnable {
        override fun run() {
            if (stopped) return
            val t    = nativeGetTimeMicros()
            val minU = nativeGetMinMicros()
            val maxU = nativeGetMaxMicros()
            if (::seekBar.isInitialized && !userSeeking && maxU > minU)
                seekBar.progress = (((t - minU) * 1000L) / (maxU - minU)).toInt()
            if (::loadingOverlay.isInitialized &&
                loadingOverlay.visibility == View.VISIBLE) {
                if (nativeIsPlaying()) {
                    loadingOverlay.visibility = View.GONE
                } else {
                    // Engine aborted during start-up (synth or GL init). Show why
                    // instead of an infinite "Starting…" and stop polling — the
                    // user can back out. Full driver error is in logcat (tag aPFA).
                    val err = nativeGetStartError()
                    if (err != 0) {
                        loadingOverlay.text = when (err) {
                            1 -> "Audio engine failed to start.\n\n" +
                                 "This device's audio output could not be opened."
                            2 -> "Graphics failed to initialize.\n\n" +
                                 "If this is an older (OpenGL ES 2.0) device, enable " +
                                 "\"Legacy Renderer (GLES 2.0)\" in Advanced Settings > GFX and try " +
                                 "again. See logcat (tag aPFA) for details."
                            else -> "Playback failed to start."
                        }
                        return
                    }
                }
            }
            ui.postDelayed(this, 16)
        }
    }

    // ---- SurfaceHolder.Callback ----
    // Surface lifecycle (attach/detach the render thread) is deliberately kept
    // separate from the engine's lifecycle. Going to recents destroys the surface,
    // so we only stop the render thread here — the engine and its parsed MIDI live
    // on, and surfaceCreated re-attaches and resumes. The engine is freed only in
    // onDestroy (nativeRelease).

    override fun surfaceCreated(holder: SurfaceHolder)  { if (newest) nativeStart(holder.surface) }
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
        if (newest) nativeSurfaceChanged(w, h)
    }
    override fun surfaceDestroyed(holder: SurfaceHolder) { if (newest) nativeStop() }

    // ---- lifecycle ----

    override fun onPause()  { super.onPause();  if (newest) nativePause() }
    override fun onResume() { super.onResume(); if (newest && !paused) nativeResume() }

    private fun toggleUi() {
        if (!hasActionBar) return  // nothing to hide — already bare
        uiHidden = !uiHidden
        actionBar?.let { ab ->
            if (uiHidden) ab.hide() else ab.show()
        }
    }

    private fun togglePause() {
        paused = !paused
        if (paused) nativePause() else nativeResume()
        if (::pauseButton.isInitialized)
            pauseButton.text = if (paused) "▶" else "❚❚"
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /**
     * A SurfaceView that measures itself to the largest [aw]:[ah] rectangle
     * inside what its parent offers. Re-fits on its own when the action bar
     * hides or shows, since that re-measures the content area.
     */
    private class FittedSurfaceView(ctx: android.content.Context,
                                    private val aw: Int, private val ah: Int) : SurfaceView(ctx) {
        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val w = View.MeasureSpec.getSize(widthMeasureSpec)
            val h = View.MeasureSpec.getSize(heightMeasureSpec)
            if (w == 0 || h == 0) { setMeasuredDimension(w, h); return }
            if (w.toLong() * ah > h.toLong() * aw)
                setMeasuredDimension((h.toLong() * aw / ah).toInt(), h)   // pillarbox
            else
                setMeasuredDimension(w, (w.toLong() * ah / aw).toInt())   // letterbox
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopped = true
        ui.removeCallbacksAndMessages(null)
        // A newer playback owns the engine and the copies now; its nativeLoad
        // already freed this one's engine.
        if (!newest) return
        nativeRelease()   // activity finishing for real — free the engine + MIDI
        clearCopies(cacheDir)
    }

    // ---- helpers ----

    // Decode the chosen background (downscaled to BG_MAX_DIM), pull its ARGB
    // pixels, and hand them to the engine. Stretching to fit happens in the GL
    // shader, so we don't care about aspect ratio here.
    private fun applyBgImage(path: String) {
        try {
            // First pass: bounds only, to pick a power-of-two downsample factor.
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return
            var sample = 1
            while (bounds.outWidth / sample > BG_MAX_DIM ||
                   bounds.outHeight / sample > BG_MAX_DIM) sample *= 2

            val opts = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val bmp = BitmapFactory.decodeFile(path, opts) ?: return
            val w = bmp.width
            val h = bmp.height
            val pixels = IntArray(w * h)
            bmp.getPixels(pixels, 0, w, 0, 0, w, h)
            bmp.recycle()
            nativeSetBgImage(pixels, w, h)
        } catch (e: Exception) {
            Log.e("aPFA", "applyBgImage failed", e)
        }
    }

    // ---- Soundfont preparation ------------------------------------------
    //
    // SF2 and SF3 are single self-contained files: any copy of the bytes plays.
    // SFZ is not. An .sfz is a TEXT file that names its samples — and any
    // further .sfz files — by RELATIVE path, so it only works while it sits in
    // its own folder next to them. Copying just the .sfz into the cache, which
    // is what this did for every soundfont, produced a font that parsed and
    // then rendered silence.
    //
    // Two routes, best first:
    //   1. Hand BASSMIDI the file where it already lives. Costs nothing and the
    //      samples resolve themselves. Covers the pre-SAF browser's file:// URIs
    //      and any content:// URI still readable as a path (i.e. below API 29,
    //      before scoped storage).
    //   2. Rebuild the instrument in the cache: copy the .sfz, parse it, and
    //      pull every file it names through the same provider, preserving the
    //      relative layout so the paths inside the .sfz stay correct.
    //
    // Route 2 is best-effort by nature — SAF grants one document, not its
    // folder — so it reports what it actually fetched instead of pretending.
    private fun prepareSoundfont(uriStr: String): String {
        val uri   = Uri.parse(uriStr)
        val name  = sanitiseName(displayName(uri))
        val isSfz = name.endsWith(".sfz", ignoreCase = true)

        val local = resolveLocalPath(uri)
        if (local != null && File(local).canRead()) {
            Log.i("aPFA", "soundfont: playing in place, $local")
            return local
        }
        if (!isSfz) return copyToCache(uriStr, name) ?: ""
        return bundleSfz(uri, name) ?: ""
    }

    /** The same SAF URI with its document id repointed at a sibling file. */
    private fun siblingUri(uri: Uri, rel: String): Uri? {
        val segs = uri.pathSegments ?: return null
        val i = segs.lastIndexOf("document")
        if (i < 0 || i + 1 >= segs.size) return null
        val id  = segs[i + 1]
        val cut = id.lastIndexOf('/')
        if (cut < 0) return null
        val b = Uri.Builder().scheme(uri.scheme).authority(uri.authority)
        segs.forEachIndexed { idx, seg ->
            b.appendPath(if (idx == i + 1) id.substring(0, cut + 1) + rel else seg)
        }
        return b.build()
    }

    /**
     * Rebuild an SFZ instrument under cache/sfz, keeping every path relative to
     * the .sfz exactly as written so BASSMIDI resolves them unchanged. Returns
     * the path to the copied .sfz, or null if even that could not be read.
     */
    private fun bundleSfz(uri: Uri, rootName: String): String? {
        val dir = File(cacheDir, "sfz")
        wipe(dir)
        if (!dir.mkdirs() && !dir.isDirectory) {
            Log.e("aPFA", "sfz: could not create $dir")
            return null
        }
        val localRoot = resolveLocalPath(uri)

        // Breadth-first over the instrument. Paths are relative to the .sfz's
        // own folder, which is also the layout we write, so one string does for
        // both the source lookup and the destination.
        val queue = ArrayList<String>()
        val seen  = HashSet<String>()
        queue.add(rootName)
        seen.add(rootName)

        var qi = 0
        var files = 0
        var bytes = 0L
        var missing = 0
        var rootOk = false
        var capped = false

        while (qi < queue.size) {
            val rel = queue[qi++]
            if (files >= SFZ_MAX_FILES || bytes >= SFZ_MAX_BYTES) { capped = true; break }
            val out = File(dir, rel)
            if (!withinBundle(dir, out)) {
                Log.w("aPFA", "sfz: refusing path outside the bundle: $rel")
                continue
            }
            out.parentFile?.mkdirs()
            val n = fetchInto(uri, localRoot, rootName, rel, out)
            if (n < 0) {
                if (rel == rootName) { Log.e("aPFA", "sfz: cannot read $rel"); return null }
                missing++
                Log.w("aPFA", "sfz: could not fetch $rel")
                continue
            }
            files++
            bytes += n
            if (rel == rootName) rootOk = true
            if (rel.endsWith(".sfz", ignoreCase = true) && out.length() <= SFZ_MAX_TEXT) {
                val refs = try {
                    sfzReferences(out.readText())
                } catch (e: Exception) {
                    Log.w("aPFA", "sfz: unreadable text in $rel", e)
                    emptyList<String>()
                }
                for (r in refs) if (seen.add(r)) queue.add(r)
            }
        }
        if (!rootOk) return null

        Log.i("aPFA", "sfz: bundled $files file(s), %.1f MB, $missing missing%s"
            .format(bytes / 1048576.0, if (capped) " (capped)" else ""))
        if (missing > 0 || capped) {
            val why = if (capped)
                "This SFZ is larger than aPFA will copy ($files files)."
            else
                "$missing sample file(s) of this SFZ could not be read."
            ui.post {
                Toast.makeText(this,
                    "$why It may play silent or incomplete. Picking it from " +
                    "internal storage, or using a .sf2, avoids this.",
                    Toast.LENGTH_LONG).show()
            }
        }
        return File(dir, rootName).absolutePath
    }

    /** Pull one file of the instrument into [out]. Returns bytes written, or -1. */
    private fun fetchInto(base: Uri, localRoot: String?, rootName: String,
                          rel: String, out: File): Long {
        // The root is the one document the picker actually granted.
        if (rel == rootName) {
            try {
                contentResolver.openInputStream(base)?.use { return writeTo(it, out) }
            } catch (e: Exception) {
                Log.w("aPFA", "sfz: root open failed", e)
            }
        } else {
            // A SAF grant is per-document, but ExternalStorageProvider will
            // often still answer for a sibling of a granted file — and on
            // API 29+ this is the only route there is.
            siblingUri(base, rel)?.let { sib ->
                try {
                    contentResolver.openInputStream(sib)?.use { return writeTo(it, out) }
                } catch (e: Exception) {
                    // not granted, or not that kind of provider — try the path
                }
            }
        }
        if (localRoot != null) {
            val parent = File(localRoot).parentFile
            if (parent != null) {
                val f = File(parent, rel)
                if (f.canRead()) try {
                    FileInputStream(f).use { return writeTo(it, out) }
                } catch (e: Exception) {
                    Log.w("aPFA", "sfz: path read failed for $rel", e)
                }
            }
        }
        out.delete()
        return -1
    }

    private fun writeTo(input: InputStream, out: File): Long =
        FileOutputStream(out).use { o -> input.copyTo(o, 1 shl 16) }

    /**
     * Every file an .sfz names: sample= values (prefixed by the running
     * default_path=) plus #include targets, as relative '/'-separated paths.
     *
     * SFZ packs several opcode=value pairs per line and treats // as a comment.
     * sample= is the awkward one — filenames may contain spaces, so its value
     * runs to the next opcode token, the next <header>, or end of line, NOT to
     * the next space. Paths are conventionally written with backslashes.
     */
    private fun sfzReferences(text: String): List<String> {
        val lines = text.split('\n')

        // Pass 1 — #define. Collected up front so a macro defined below its
        // first use still resolves: this is a hunt for files, not a render, so
        // the widest reading is the right one. Longest name first, or $E would
        // eat the head of $EXT.
        val defines = ArrayList<Pair<String, String>>()
        for (raw in lines) SFZ_DEFINE.find(raw)?.let {
            defines.add(Pair(it.groupValues[1], it.groupValues[2]))
        }
        defines.sortByDescending { it.first.length }

        val out = ArrayList<String>()
        var defaultPath = ""
        for (line0 in lines) {
            if (SFZ_DEFINE.containsMatchIn(line0)) continue
            val raw = expandDefines(line0, defines)
            val incl = SFZ_INCLUDE.find(raw)
            if (incl != null) {
                normalise(incl.groupValues[1])?.let { out.add(it) }
                continue
            }
            val c = raw.indexOf("//")
            val line = if (c >= 0) raw.substring(0, c) else raw
            val hits = SFZ_OPCODE.findAll(line).toList()
            for ((n, m) in hits.withIndex()) {
                val from = m.range.last + 1
                val to   = if (n + 1 < hits.size) hits[n + 1].range.first else line.length
                var v = line.substring(from, to)
                val lt = v.indexOf('<')          // a header ends the value
                if (lt >= 0) v = v.substring(0, lt)
                v = v.trim()
                when (m.groupValues[1].lowercase()) {
                    "sample" -> if (v.isNotEmpty())
                        normalise(defaultPath + v)?.let { out.add(it) }
                    "default_path" -> {
                        val d = v.replace('\\', '/')
                        defaultPath = if (d.isEmpty() || d.endsWith("/")) d else "$d/"
                    }
                }
            }
        }
        return out
    }

    private fun expandDefines(line: String, defines: List<Pair<String, String>>): String {
        if (defines.isEmpty() || line.indexOf('$') < 0) return line
        var s = line
        for ((k, v) in defines) s = s.replace(k, v)
        return s
    }

    /**
     * A referenced path reduced to a safe relative one. Absolute paths (a
     * leftover "C:\..." or "/home/...") and anything climbing out of the
     * instrument folder are dropped rather than chased.
     */
    private fun normalise(p: String): String? {
        val s = p.trim().trim('"').replace('\\', '/')
        if (s.isEmpty()) return null
        if (s.startsWith("/")) return null
        if (s.length > 1 && s[1] == ':') return null
        val parts = ArrayList<String>()
        for (seg in s.split('/')) {
            when (seg) {
                "", "." -> {}
                ".."    -> if (parts.isEmpty()) return null else parts.removeAt(parts.size - 1)
                else    -> parts.add(seg)
            }
        }
        return if (parts.isEmpty()) null else parts.joinToString("/")
    }

    private fun withinBundle(root: File, f: File): Boolean = try {
        f.canonicalPath.startsWith(root.canonicalPath + File.separator)
    } catch (e: Exception) {
        false
    }

    private fun wipe(f: File) {
        if (f.isDirectory) f.listFiles()?.forEach { wipe(it) }
        f.delete()
    }

    /** Keep the picked name (and its extension) but make it safe as a filename. */
    private fun sanitiseName(n: String): String {
        val base = n.substringAfterLast('/').substringAfterLast('\\')
        val safe = base.replace(Regex("[^A-Za-z0-9._ -]"), "_").trim()
        return if (safe.isEmpty() || safe == "." || safe == "..") "font.sf2" else safe
    }

    private fun displayName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "font.sf2"
        try {
            // Closed by hand: Cursor is only Closeable from API 16 (see
            // MainActivity.displayName).
            val c = contentResolver.query(uri, null, null, null, null)
            if (c != null) try {
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) c.getString(idx)?.let { name = it }
                }
            } finally {
                c.close()
            }
        } catch (e: Exception) {
            // keep the path-segment fallback
        }
        return name
    }

    private fun copyToCache(uriStr: String, name: String): String? = try {
        val out = File(cacheDir, name)
        copiedBytes = 0
        contentResolver.openInputStream(Uri.parse(uriStr))!!.use { input ->
            FileOutputStream(out).use { output ->
                // copyTo() by hand, so the verbose line can count the bytes.
                val buf = ByteArray(1 shl 20)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    output.write(buf, 0, n)
                    copiedBytes += n
                }
            }
        }
        out.absolutePath
    } catch (e: Exception) {
        Log.e("aPFA", "copyToCache failed: $name", e)
        null
    }
}
