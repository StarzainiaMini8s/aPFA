package com.apfa

import android.annotation.TargetApi
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.TypedValue
import android.view.View
import android.widget.Button

/**
 * Light / Dark mode, and the hand-drawn pieces of the 1.4.0 look: glossy
 * buttons, the Aero glass plate and the silver version label.
 *
 * Everything here is drawn with Canvas rather than XML drawables so it runs
 * unchanged from API 10 up: no ripple, no tint lists, nothing a Gingerbread
 * phone cannot resolve.
 */
object UiTheme {

    // GFX > Theme. Stored as an int pref ("themeMode").
    const val MODE_SYSTEM = 0
    const val MODE_LIGHT  = 1
    const val MODE_DARK   = 2

    /**
     * Whether the OS is in dark mode. Only an explicit "night: yes" counts —
     * UNDEFINED (and every device too old to have a night mode at all) reads
     * as light, which is the default.
     */
    fun systemIsDark(ctx: Context): Boolean =
        (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES

    fun isDark(ctx: Context, mode: Int): Boolean = when (mode) {
        MODE_LIGHT -> false
        MODE_DARK  -> true
        else       -> systemIsDark(ctx)
    }

    /**
     * The activity theme for [dark], applied before any view is built so the
     * dialogs, checkboxes, radios and seek bars all follow it.
     *
     * Material on 21+ rather than DeviceDefault on purpose: OEM DeviceDefault
     * themes (One UI's among them) may follow the system night mode on their
     * own, which would quietly undo a "Light" override. Material is
     * CTS-locked, so Light stays light.
     */
    fun activityTheme(dark: Boolean): Int = when {
        Build.VERSION.SDK_INT >= 21 ->
            if (dark) android.R.style.Theme_Material_NoActionBar
            else      android.R.style.Theme_Material_Light_NoActionBar
        Build.VERSION.SDK_INT >= 14 ->
            if (dark) android.R.style.Theme_DeviceDefault_NoActionBar
            else      android.R.style.Theme_DeviceDefault_Light_NoActionBar
        Build.VERSION.SDK_INT >= 11 ->
            if (dark) android.R.style.Theme_Holo
            else      android.R.style.Theme_Holo_Light
        else ->
            if (dark) android.R.style.Theme_NoTitleBar
            else      android.R.style.Theme_Light_NoTitleBar
    }

    /**
     * Android 10's force-dark repaints a light theme when the system is dark.
     * A "Light" override means light, so switch it off for this window.
     * Isolated for the same Dalvik-verifier reason as hasAllFilesAccess().
     */
    @TargetApi(29)
    fun blockForceDark(activity: Activity) {
        try { activity.window.decorView.isForceDarkAllowed = false } catch (e: Throwable) {}
    }

    /**
     * A dialog builder in [dark] or light, for activities whose own theme
     * can't follow the mode (PlaybackActivity hosts its transport in the
     * action bar, which a theme swap would restyle).
     */
    fun dialogBuilder(ctx: Context, dark: Boolean): AlertDialog.Builder = when {
        Build.VERSION.SDK_INT >= 21 -> AlertDialog.Builder(ctx,
            if (dark) android.R.style.Theme_Material_Dialog_Alert
            else      android.R.style.Theme_Material_Light_Dialog_Alert)
        Build.VERSION.SDK_INT >= 14 -> AlertDialog.Builder(ctx,
            if (dark) AlertDialog.THEME_DEVICE_DEFAULT_DARK
            else      AlertDialog.THEME_DEVICE_DEFAULT_LIGHT)
        else -> AlertDialog.Builder(ctx)
    }

    /** Glossy background + matching text: black/white in dark, white/black in light. */
    @Suppress("DEPRECATION")
    fun gloss(b: Button, dark: Boolean): Button {
        val d = b.resources.displayMetrics.density
        b.setBackgroundDrawable(GlossDrawable(dark, d))
        // 15% smaller than the stock button (48 x 88 dp minimum on Material);
        // the text size is left alone. Both setters: the style's minHeight
        // lands on the TextView AND the View, and the larger one wins.
        b.minHeight = (41 * d).toInt();  b.minimumHeight = (41 * d).toInt()
        b.minWidth  = (75 * d).toInt();  b.minimumWidth  = (75 * d).toInt()
        b.setTextColor(if (dark) Color.WHITE else Color.BLACK)
        // A one-pixel emboss: dark text sits on a white lip, white text on a black one.
        b.setShadowLayer(1f, 0f, if (dark) -d else d,
                         if (dark) Color.argb(160, 0, 0, 0) else Color.argb(200, 255, 255, 255))
        return b
    }
}

/**
 * A Vista/7-style glossy button: a vertical body gradient split at the middle
 * (the hard step is what reads as "glossy"), a 1px inner highlight and a dark
 * rim. Pressed and selected (tab) states sink; focus — what a Fire TV remote
 * moves — lights the rim blue so D-pad users can still see where they are.
 */
class GlossDrawable(private val dark: Boolean, private val density: Float) : Drawable() {

    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim  = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val lip  = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()

    private var pressed = false
    private var focused = false
    private var enabled = true
    private var alpha8 = 255

    // Colours: [top, mid-above, mid-below, bottom], rim, inner lip.
    private fun palette(): Pair<IntArray, IntArray> = if (dark) when {
        pressed -> Pair(intArrayOf(0xFF262626.toInt(), 0xFF141414.toInt(), 0xFF000000.toInt(), 0xFF0C0C0C.toInt()),
                        intArrayOf(0xFF000000.toInt(), 0x22FFFFFF))
        focused -> Pair(intArrayOf(0xFF4A5A6A.toInt(), 0xFF2A3644.toInt(), 0xFF0A1420.toInt(), 0xFF14283C.toInt()),
                        intArrayOf(0xFF5FA8E0.toInt(), 0x40FFFFFF))
        else    -> Pair(intArrayOf(0xFF575757.toInt(), 0xFF2C2C2C.toInt(), 0xFF0A0A0A.toInt(), 0xFF1A1A1A.toInt()),
                        intArrayOf(0xFF000000.toInt(), 0x40FFFFFF))
    } else when {
        pressed -> Pair(intArrayOf(0xFFE5F4FC.toInt(), 0xFFC4E5F6.toInt(), 0xFF98D1EF.toInt(), 0xFF68B3DB.toInt()),
                        intArrayOf(0xFF2C628B.toInt(), 0x80FFFFFF.toInt()))
        focused -> Pair(intArrayOf(0xFFEAF6FD.toInt(), 0xFFD9F0FC.toInt(), 0xFFBEE6FD.toInt(), 0xFFA7D9F5.toInt()),
                        intArrayOf(0xFF3C7FB1.toInt(), 0xC0FFFFFF.toInt()))
        else    -> Pair(intArrayOf(0xFFFFFFFF.toInt(), 0xFFF0F0F0.toInt(), 0xFFDDDDDD.toInt(), 0xFFCFCFCF.toInt()),
                        intArrayOf(0xFF707070.toInt(), 0xC0FFFFFF.toInt()))
    }

    @Suppress("DEPRECATION")
    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val (grad, edges) = palette()
        val r = 5f * density
        val half = 0.5f * density

        // Disabled = the same button, faded, rather than a separate palette.
        val a = if (enabled) alpha8 else alpha8 * 110 / 255
        val layered = a < 255
        if (layered) canvas.saveLayerAlpha(RectF(b), a, Canvas.ALL_SAVE_FLAG)

        rect.set(b.left + half, b.top + half, b.right - half, b.bottom - half)
        body.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, grad,
                                     floatArrayOf(0f, 0.5f, 0.5f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rect, r, r, body)

        lip.color = edges[1]
        lip.strokeWidth = density
        val lr = RectF(rect.left + density, rect.top + density,
                       rect.right - density, rect.bottom - density)
        canvas.drawRoundRect(lr, r - density, r - density, lip)

        rim.color = edges[0]
        rim.strokeWidth = density
        canvas.drawRoundRect(rect, r, r, rim)

        if (layered) canvas.restore()
    }

    override fun isStateful(): Boolean = true

    override fun onStateChange(state: IntArray): Boolean {
        var p = false; var f = false; var e = false
        for (s in state) when (s) {
            android.R.attr.state_pressed, android.R.attr.state_selected -> p = true
            android.R.attr.state_focused -> f = true
            android.R.attr.state_enabled -> e = true
        }
        if (p == pressed && f == focused && e == enabled) return false
        pressed = p; focused = f; enabled = e
        invalidateSelf()
        return true
    }

    // What the stock button background used to supply; without it the label
    // would sit flush against the rim.
    override fun getPadding(padding: Rect): Boolean {
        // 85% of the 14 x 9 dp it started at, matching the smaller minimums.
        val h = (12 * density).toInt(); val v = (7.5f * density).toInt()
        padding.set(h, v, h, v)
        return true
    }

    override fun setAlpha(a: Int) { alpha8 = a; invalidateSelf() }
    override fun setColorFilter(cf: ColorFilter?) { body.colorFilter = cf; invalidateSelf() }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/**
 * paneaero.png (mini8s) behind the version label, scaled down to fit it —
 * plain layering: the whole image, rim and all, one draw, text on top.
 *
 * (It used to be nine-sliced to keep the corners square-on, but the sliced
 * edge strips drew a second, lighter frame tight around the text, inside the
 * pane's own rim. One image has one rim.)
 *
 * The shrink is large (500 px tall to a ~40 dp strip) and Android does no
 * mipmapping before API 17, so a single bilinear draw would alias the
 * streaks. Instead the bitmap is halved in steps to within 2x of the target
 * and finished with one filtered scale, once per size.
 */
class PaneDrawable(private val bmp: Bitmap) : Drawable() {

    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private var scaled: Bitmap? = null

    override fun onBoundsChange(b: Rect) {
        super.onBoundsChange(b)
        scaled = if (b.isEmpty) null else fit(b.width(), b.height())
    }

    private fun fit(w: Int, h: Int): Bitmap {
        var cur = bmp
        while (cur.width / 2 >= w && cur.height / 2 >= h) {
            val half = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (cur !== bmp) cur.recycle()
            cur = half
        }
        if (cur.width == w && cur.height == h) return cur
        val out = Bitmap.createScaledBitmap(cur, w, h, true)
        if (cur !== bmp && cur !== out) cur.recycle()
        return out
    }

    override fun draw(canvas: Canvas) {
        val s = scaled ?: return
        canvas.drawBitmap(s, bounds.left.toFloat(), bounds.top.toFloat(), paint)
    }

    override fun setAlpha(a: Int) { paint.alpha = a; invalidateSelf() }
    override fun setColorFilter(cf: ColorFilter?) { paint.colorFilter = cf; invalidateSelf() }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/**
 * "aPFA v1.4.0": a gentle silver gradient with a black outline, no shadow.
 * Deliberately mode-independent — it sits on the wallpaper and the
 * glass plate, neither of which changes with the theme.
 *
 * A plain View rather than a TextView: TextView resets its paint colour from
 * the text colour on every draw, so a stroke-then-fill pass through it means
 * calling setTextColor() inside onDraw(), which re-invalidates forever.
 */
class SilverText(ctx: Context, private val text: String, sizeSp: Float) : View(ctx) {

    private val density = ctx.resources.displayMetrics.density
    private val outline = 1.5f * density          // drawn outside the glyphs

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD
        textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sizeSp,
                                             ctx.resources.displayMetrics)
        style = Paint.Style.STROKE
        strokeWidth = outline * 2                 // centred on the edge: half lands outside
        strokeJoin = Paint.Join.ROUND
        color = Color.BLACK
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = stroke.typeface
        textSize = stroke.textSize
        style = Paint.Style.FILL
    }

    init {
        contentDescription = text
    }

    private val pad get() = outline.toInt() + 1

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val fm = stroke.fontMetrics
        val w = stroke.measureText(text) + 2 * pad
        val h = (fm.descent - fm.ascent) + 2 * pad
        setMeasuredDimension(resolveSize(w.toInt() + 1, widthMeasureSpec),
                             resolveSize(h.toInt() + 1, heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        val fm = stroke.fontMetrics
        val x = pad.toFloat()
        val baseline = pad - fm.ascent
        val top = baseline + fm.ascent
        val bottom = baseline + fm.descent
        // Gentle: bright at the cap line, a soft dip just past the middle,
        // back up toward the baseline — brushed metal, not chrome.
        fill.shader = LinearGradient(0f, top, 0f, bottom,
            intArrayOf(0xFFFFFFFF.toInt(), 0xFFE4E6E9.toInt(), 0xFFB8BCC2.toInt(), 0xFFD8DBDF.toInt()),
            floatArrayOf(0f, 0.42f, 0.62f, 1f), Shader.TileMode.CLAMP)
        canvas.drawText(text, x, baseline, stroke)
        canvas.drawText(text, x, baseline, fill)
    }
}
