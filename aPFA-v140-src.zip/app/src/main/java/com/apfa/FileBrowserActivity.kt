package com.apfa

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.InsetDrawable
import android.os.Bundle
import android.os.Environment
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.io.File

/**
 * aPFA's own file browser, used instead of the system picker for MIDIs and
 * soundfonts (and as the last resort for everything else).
 *
 * Laid out from apfa-design-new-file-manager/: a glossy header with the title
 * on the left and the current folder on the right, a search row, a full-width
 * divider, then the scrolling list — folders first, then only the files this
 * pick can use, each with its size. Pseudo-Holo: Holo's blue accent and
 * dividers, with the setup screen's gloss on the header, the folder button and
 * the pressed rows. Dark or light to match the setup screen.
 *
 * Built from plain Views and Canvas drawing, so it runs unchanged down to
 * Android 2.3 (API 10): no action bar, no fragments, no RecyclerView.
 *
 * Save mode (EXTRA_SAVE_NAME set — Export Profile): the search row becomes
 * the file name, a "Save here" button joins the header, and tapping an
 * existing file of the right kind takes its name, to overwrite it.
 *
 * The pick comes back as a filesystem path in EXTRA_PATH, deliberately not as
 * a file:// data URI — from API 24 a file:// URI on a result intent trips
 * FileUriExposedException, even between two activities of the same app.
 */
class FileBrowserActivity : Activity() {

    companion object {
        const val EXTRA_TITLE      = "title"
        const val EXTRA_EXTENSIONS = "extensions"   // lower case, no dot
        const val EXTRA_KIND       = "kind"         // remembers a last folder per kind
        const val EXTRA_DARK       = "dark"
        const val EXTRA_SAVE_NAME  = "saveName"     // save mode: suggested file name
        const val EXTRA_PATH       = "path"         // result

        // Holo's accent, as used for its dividers and pressed states.
        private const val HOLO_BLUE = 0xFF33B5E5.toInt()

        // The longest name a row shows; past it the middle goes, the
        // extension stays (from the sketch: "50 characters max").
        private const val NAME_MAX = 50
    }

    private class Entry(val file: File, val isDir: Boolean, val size: Long, val isUp: Boolean = false)

    private var dark = false
    private var extensions: Array<String> = emptyArray()
    private var kind = ""
    private var saveMode = false

    private var dir: File? = null
    private var root: File? = null                 // the storage root the user is in
    private var listing: List<Entry> = emptyList()  // everything in dir
    private var shown: List<Entry> = emptyList()    // after the search filter
    private var generation = 0                      // drops stale background listings
    private var loading = false

    private lateinit var dirButton: Button
    private lateinit var search: EditText
    private lateinit var list: ListView
    private lateinit var empty: TextView
    private lateinit var adapter: EntryAdapter

    // Theme colours.
    private val textPrimary get() = if (dark) Color.WHITE else Color.BLACK
    private val textSecondary get() = if (dark) Color.rgb(190, 190, 190) else Color.rgb(90, 90, 90)

    override fun onCreate(savedInstanceState: Bundle?) {
        dark = intent.getBooleanExtra(EXTRA_DARK, false)
        setTheme(UiTheme.activityTheme(dark))
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        // The list, not the search box, takes focus at open: no keyboard
        // springing up on a phone, and a TV remote lands straight on the files.
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)

        extensions = intent.getStringArrayExtra(EXTRA_EXTENSIONS) ?: emptyArray()
        kind = intent.getStringExtra(EXTRA_KIND) ?: ""
        val saveName = intent.getStringExtra(EXTRA_SAVE_NAME)
        saveMode = saveName != null
        setContentView(buildUi(intent.getStringExtra(EXTRA_TITLE) ?: "Choose a file"))
        if (!dark && android.os.Build.VERSION.SDK_INT >= 29) UiTheme.blockForceDark(this)

        if (saveName != null) search.setText(saveName)
        val start = startDir()
        root = rootOf(start)
        open(start)
        list.requestFocus()
    }

    // ---- layout ---------------------------------------------------------------

    @Suppress("DEPRECATION")   // setBackgroundDrawable: setBackground is API 16
    private fun buildUi(title: String): View {
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setBackgroundDrawable(PageDrawable(dark))

        // --- header: title (left) + current folder (right), on a gloss bar ---
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setBackgroundDrawable(BarDrawable(dark, resources.displayMetrics.density))
        header.setPadding(dp(16), dp(8), dp(10), dp(8))

        val titleView = TextView(this)
        titleView.text = title
        titleView.textSize = 20f
        titleView.typeface = Typeface.DEFAULT_BOLD
        titleView.setTextColor(textPrimary)
        titleView.setSingleLine(true)
        titleView.ellipsize = TextUtils.TruncateAt.END
        header.addView(titleView, LinearLayout.LayoutParams(0, wc, 1f))

        dirButton = UiTheme.gloss(Button(this), dark)
        dirButton.setSingleLine(true)
        dirButton.ellipsize = TextUtils.TruncateAt.START   // keep the folder you are IN
        dirButton.maxWidth = (resources.displayMetrics.widthPixels * 0.45f).toInt()
        dirButton.setOnClickListener { showRoots() }
        header.addView(dirButton, LinearLayout.LayoutParams(wc, wc).apply { leftMargin = dp(12) })
        if (intent.getStringExtra(EXTRA_SAVE_NAME) != null) {
            val saveButton = UiTheme.gloss(Button(this), dark)
            saveButton.text = "Save here"
            saveButton.setOnClickListener { saveHere() }
            header.addView(saveButton, LinearLayout.LayoutParams(wc, wc).apply { leftMargin = dp(8) })
        }
        page.addView(header, LinearLayout.LayoutParams(mp, wc))

        // --- search row: magnifier + "Tap to Search" ---
        val searchRow = LinearLayout(this)
        searchRow.orientation = LinearLayout.HORIZONTAL
        searchRow.gravity = Gravity.CENTER_VERTICAL
        searchRow.setPadding(dp(16), dp(8), dp(16), dp(8))

        val saving = intent.getStringExtra(EXTRA_SAVE_NAME) != null
        if (saving) {
            val label = TextView(this)
            label.text = "File name"
            label.textSize = 15f
            label.setTextColor(textSecondary)
            searchRow.addView(label, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { rightMargin = dp(10) })
        } else {
            val icon = View(this)
            icon.setBackgroundDrawable(SearchIconDrawable(textSecondary, resources.displayMetrics.density))
            searchRow.addView(icon, LinearLayout.LayoutParams(dp(24), dp(24)).apply { rightMargin = dp(10) })
        }

        search = EditText(this)
        search.hint = if (saving) "Name this file" else "Tap to Search"
        search.setSingleLine(true)
        search.textSize = 16f
        search.setTextColor(textPrimary)
        search.setHintTextColor(textSecondary)
        search.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        search.imeOptions = (if (saving) EditorInfo.IME_ACTION_DONE else EditorInfo.IME_ACTION_SEARCH) or
                            EditorInfo.IME_FLAG_NO_EXTRACT_UI
        search.setBackgroundDrawable(FieldDrawable(dark, resources.displayMetrics.density))
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = applyFilter()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                hideKeyboard(); list.requestFocus(); true
            }
            else false
        }
        searchRow.addView(search, LinearLayout.LayoutParams(0, wc, 1f))
        page.addView(searchRow, LinearLayout.LayoutParams(mp, wc))

        // --- the full-width divider: Holo blue ---
        val divider = View(this)
        divider.setBackgroundColor(HOLO_BLUE)
        page.addView(divider, LinearLayout.LayoutParams(mp, dp(2)))

        // --- the list ---
        list = ListView(this)
        list.isFastScrollEnabled = true                // Black MIDI folders get long
        list.cacheColorHint = Color.TRANSPARENT        // no black flash on 2.3 while flinging
        // "Small divider": a hairline, inset past the icon column like Holo's.
        list.divider = InsetDrawable(
            ColorDrawable(if (dark) Color.rgb(48, 48, 48) else Color.rgb(212, 212, 212)),
            dp(56), 0, dp(16), 0)
        list.dividerHeight = 1
        list.selector = RowDrawable(dark, resources.displayMetrics.density)
        list.isFocusable = true
        adapter = EntryAdapter()
        list.adapter = adapter
        list.onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ ->
            val e = shown.getOrNull(pos) ?: return@OnItemClickListener
            when {
                e.isUp  -> up()
                e.isDir -> { if (!saveMode) search.setText(""); open(e.file) }
                saveMode -> search.setText(e.file.name)   // overwrite this one
                else    -> pick(e.file)
            }
        }

        empty = TextView(this)
        empty.textSize = 15f
        empty.setTextColor(textSecondary)
        empty.gravity = Gravity.CENTER
        empty.setPadding(dp(24), dp(24), dp(24), dp(24))

        val listBox = android.widget.FrameLayout(this)
        listBox.addView(list, android.widget.FrameLayout.LayoutParams(mp, mp))
        listBox.addView(empty, android.widget.FrameLayout.LayoutParams(mp, wc))
        page.addView(listBox, LinearLayout.LayoutParams(mp, 0, 1f))
        return page
    }

    // ---- navigation -----------------------------------------------------------

    private fun prefs() = getSharedPreferences("filebrowser", Context.MODE_PRIVATE)

    // The last folder this kind of pick was made from, else Download (the
    // sketch's default), else the storage root, else aPFA's own folder.
    private fun startDir(): File {
        prefs().getString("dir_$kind", null)?.let { File(it) }
            ?.takeIf { it.isDirectory && it.listFiles() != null }?.let { return it }
        val ext = Environment.getExternalStorageDirectory()
        val dl = File(ext, Environment.DIRECTORY_DOWNLOADS)
        if (dl.isDirectory) return dl
        if (ext.isDirectory) return ext
        return getExternalFilesDir(null) ?: filesDir
    }

    /** The storage root [f] sits under, so Back and Up know where to stop. */
    private fun rootOf(f: File): File {
        val path = canonical(f)
        return storageRoots().map { it.second }
            .filter { path == canonical(it) || path.startsWith(canonical(it) + "/") }
            .maxByOrNull { canonical(it).length } ?: f
    }

    private fun canonical(f: File): String =
        try { f.canonicalPath } catch (e: Exception) { f.absolutePath }

    private fun atRoot(): Boolean {
        val d = dir ?: return true
        val r = root ?: return true
        return canonical(d) == canonical(r)
    }

    private fun open(target: File) {
        dir = target
        dirButton.text = folderLabel(target)
        empty.text = "Loading…"
        loading = true
        listing = emptyList()
        applyFilter()
        // Listed off the UI thread: a card or a folder of thousands of MIDIs
        // can take a while to stat, and the screen should stay live meanwhile.
        val gen = ++generation
        Thread {
            val all = target.listFiles()        // null = unreadable, not empty
            val result = scan(target, all ?: emptyArray())
            runOnUiThread {
                if (gen != generation || isFinishing) return@runOnUiThread
                loading = false
                listing = result
                empty.text = when {
                    all == null -> "Can't read this folder."
                    saveMode -> "Empty folder. \"Save here\" will put the file in it."
                    else -> "Nothing here aPFA can open (" +
                            extensions.joinToString("/") { ".$it" } + ")."
                }
                applyFilter()
                list.setSelection(0)
            }
        }.start()
    }

    private fun scan(target: File, all: Array<File>): List<Entry> {
        val folders = ArrayList<Entry>()
        val files = ArrayList<Entry>()
        for (f in all) {
            if (f.name.startsWith(".")) continue
            if (f.isDirectory) folders.add(Entry(f, true, 0))
            else if (f.isFile) {
                val ext = f.name.substringAfterLast('.', "").lowercase()
                if (extensions.isEmpty() || ext in extensions) files.add(Entry(f, false, f.length()))
            }
        }
        folders.sortBy { it.file.name.lowercase() }
        files.sortBy { it.file.name.lowercase() }
        val out = ArrayList<Entry>(folders.size + files.size + 1)
        if (!atRootFor(target)) target.parentFile?.let { out.add(Entry(it, true, 0, isUp = true)) }
        out.addAll(folders)
        out.addAll(files)
        return out
    }

    private fun atRootFor(f: File): Boolean {
        val r = root ?: return true
        return canonical(f) == canonical(r)
    }

    /** Live search: filters this folder's listing by name as you type. */
    private fun applyFilter() {
        // In save mode the field is the file name, not a search.
        val q = if (saveMode) "" else search.text.toString().trim().lowercase()
        shown = if (q.isEmpty()) listing
                else listing.filter { !it.isUp && it.file.name.lowercase().contains(q) }
        adapter.notifyDataSetChanged()
        empty.visibility = if (shown.isEmpty() || loading) View.VISIBLE else View.GONE
        if (shown.isEmpty() && q.isNotEmpty() && !loading) empty.text = "No matches for \"$q\"."
    }

    private fun up() {
        val parent = dir?.parentFile
        if (parent == null || atRoot()) return
        if (!saveMode) search.setText("")
        open(parent)
    }

    /**
     * Save mode: the folder on screen plus the typed name, given this pick's
     * extension if it lacks one. An existing file is only replaced after
     * asking. Whether the write itself succeeds is the caller's to report —
     * it holds the data and has a fallback folder.
     */
    private fun saveHere() {
        val d = dir ?: return
        var name = search.text.toString().trim()
        if (name.isEmpty() || name.contains('/') || name == "." || name == "..") {
            android.widget.Toast.makeText(this, "Type a file name first",
                                          android.widget.Toast.LENGTH_SHORT).show()
            search.requestFocus()
            return
        }
        val ext = name.substringAfterLast('.', "").lowercase()
        if (extensions.isNotEmpty() && ext !in extensions) name += "." + extensions[0]
        val target = File(d, name)
        if (!d.canWrite()) {
            android.widget.Toast.makeText(this, "aPFA can't write to this folder",
                                          android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        if (target.exists()) {
            AlertDialog.Builder(this)
                .setTitle("Replace file?")
                .setMessage("$name already exists here. Replace it?")
                .setPositiveButton("Replace") { _, _ -> pick(target) }
                .setNegativeButton("Cancel", null)
                .show()
        } else pick(target)
    }

    private fun pick(f: File) {
        dir?.let { prefs().edit().putString("dir_$kind", it.absolutePath).apply() }
        setResult(RESULT_OK, Intent().putExtra(EXTRA_PATH, f.absolutePath))
        finish()
    }

    // BACK clears a search, then climbs, and only leaves from a storage root —
    // a remote has no other way up.
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (!saveMode && search.text.isNotEmpty()) { search.setText(""); list.requestFocus(); return true }
            if (!atRoot()) { up(); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---- storage roots ----------------------------------------------------------

    /**
     * Every place worth starting from. A Fire Stick has no obvious /sdcard in
     * the user's head and may have a USB drive attached, so the folder button
     * opens a list of roots rather than assuming internal storage.
     */
    private fun storageRoots(): List<Pair<String, File>> {
        val seen = LinkedHashMap<String, Pair<String, File>>()
        fun add(label: String, d: File?) {
            if (d == null || !d.isDirectory) return
            val key = canonical(d)
            if (!seen.containsKey(key)) seen[key] = Pair(label, d)
        }
        add("Internal storage", Environment.getExternalStorageDirectory())
        // Cards and USB-OTG drives mount under /storage as a VOLUME-ID.
        // listFiles() is the readability test: canRead() lies on some mounts.
        File("/storage").listFiles()?.forEach { v ->
            if (v.isDirectory && v.name != "self" && v.name != "emulated" &&
                v.listFiles() != null) add(v.name, v)
        }
        // Always reachable, no permission of any kind required — the folder
        // to sideload files into when all else fails.
        add("aPFA folder (always readable)", getExternalFilesDir(null))
        return ArrayList(seen.values)
    }

    private fun showRoots() {
        val roots = storageRoots()
        val labels = ArrayList<String>()
        labels.add("Download")
        for ((label, d) in roots) labels.add("$label  —  ${d.absolutePath}")
        AlertDialog.Builder(this)
            .setTitle("Go to")
            .setItems(labels.toTypedArray()) { _, which ->
                val target = if (which == 0)
                    File(Environment.getExternalStorageDirectory(), Environment.DIRECTORY_DOWNLOADS)
                else roots[which - 1].second
                if (!saveMode) search.setText("")
                root = rootOf(target)
                open(target)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // "/Download" under internal storage, "<card id>/Music" on a card.
    private fun folderLabel(d: File): String {
        val r = root ?: return d.absolutePath
        val rel = canonical(d).removePrefix(canonical(r))
        val name = storageRoots().firstOrNull { canonical(it.second) == canonical(r) }?.first
        return when {
            name == "Internal storage" -> if (rel.isEmpty()) "/" else rel
            name != null               -> name + rel
            else                       -> d.absolutePath
        }
    }

    // ---- rows -------------------------------------------------------------------

    private inner class EntryAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? LinearLayout) ?: newRow()
            val e = shown[position]
            val icon = row.getChildAt(0)
            val name = row.getChildAt(1) as TextView
            val size = row.getChildAt(2) as TextView
            (icon.tag as IconDrawable).kind = when {
                e.isUp  -> IconDrawable.UP
                e.isDir -> IconDrawable.FOLDER
                else    -> IconDrawable.FILE
            }
            icon.invalidate()
            name.text = when {
                e.isUp -> "Up to " + (e.file.name.ifEmpty { "/" })
                else   -> clipName(e.file.name)
            }
            size.text = if (e.isDir) "" else humanSize(e.size)
            return row
        }

        @Suppress("DEPRECATION")
        private fun newRow(): LinearLayout {
            val row = LinearLayout(this@FileBrowserActivity)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.minimumHeight = dp(52)
            row.setPadding(dp(16), dp(6), dp(16), dp(6))

            val icon = View(this@FileBrowserActivity)
            val d = IconDrawable(dark, resources.displayMetrics.density)
            icon.setBackgroundDrawable(d)
            icon.tag = d
            row.addView(icon, LinearLayout.LayoutParams(dp(26), dp(26)).apply { rightMargin = dp(14) })

            val name = TextView(this@FileBrowserActivity)
            name.textSize = 16f
            name.setTextColor(textPrimary)
            name.setSingleLine(true)
            name.ellipsize = TextUtils.TruncateAt.MIDDLE   // only if 50 chars still won't fit
            row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val size = TextView(this@FileBrowserActivity)
            size.textSize = 13f
            size.setTextColor(textSecondary)
            size.gravity = Gravity.END
            row.addView(size, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(12) })
            return row
        }
    }

    // At most NAME_MAX characters, keeping the extension: the end of a Black
    // MIDI's name is usually the part that tells two versions apart, but the
    // extension is what says it's the right kind of file.
    private fun clipName(n: String): String {
        if (n.length <= NAME_MAX) return n
        val dot = n.lastIndexOf('.')
        val ext = if (dot > 0 && n.length - dot <= 6) n.substring(dot) else ""
        return n.substring(0, NAME_MAX - ext.length - 1) + "…" + ext
    }

    private fun humanSize(bytes: Long): String = when {
        bytes >= 1L shl 30 -> String.format("%.1f GB", bytes / (1L shl 30).toDouble())
        bytes >= 1L shl 20 -> String.format("%.1f MB", bytes / (1L shl 20).toDouble())
        bytes >= 1L shl 10 -> String.format("%.0f KB", bytes / (1L shl 10).toDouble())
        else               -> "$bytes B"
    }

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}

// ---- drawables ------------------------------------------------------------------
// All Canvas, all API 1.

/** Holo's page background: near-black with a faint blue-grey lift, or Holo light's off-white. */
private class PageDrawable(private val dark: Boolean) : Drawable() {
    private val paint = Paint()
    override fun draw(canvas: Canvas) {
        val b = bounds
        paint.shader = if (dark)
            LinearGradient(0f, b.top.toFloat(), 0f, b.bottom.toFloat(),
                           0xFF000000.toInt(), 0xFF1C2126.toInt(), Shader.TileMode.CLAMP)
        else
            LinearGradient(0f, b.top.toFloat(), 0f, b.bottom.toFloat(),
                           0xFFF6F6F6.toInt(), 0xFFE8E8E8.toInt(), Shader.TileMode.CLAMP)
        canvas.drawRect(b, paint)
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

/** The header: the buttons' split gloss, stretched into a bar. */
private class BarDrawable(private val dark: Boolean, private val density: Float) : Drawable() {
    private val paint = Paint()
    private val line = Paint()
    override fun draw(canvas: Canvas) {
        val b = bounds
        val colors = if (dark)
            intArrayOf(0xFF3C3C3C.toInt(), 0xFF262626.toInt(), 0xFF101010.toInt(), 0xFF1A1A1A.toInt())
        else
            intArrayOf(0xFFFFFFFF.toInt(), 0xFFF2F2F2.toInt(), 0xFFE0E0E0.toInt(), 0xFFD6D6D6.toInt())
        paint.shader = LinearGradient(0f, b.top.toFloat(), 0f, b.bottom.toFloat(), colors,
                                      floatArrayOf(0f, 0.5f, 0.5f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRect(b, paint)
        // 1px highlight along the top edge, as on the buttons.
        line.color = if (dark) 0x30FFFFFF else 0xC0FFFFFF.toInt()
        canvas.drawRect(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(),
                        b.top + density, line)
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

/** The search box: an inset well, Holo-blue rim while focused. */
private class FieldDrawable(private val dark: Boolean, private val density: Float) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()
    private var focused = false

    override fun draw(canvas: Canvas) {
        val b = bounds
        val r = 4f * density
        rect.set(b.left + density, b.top + density, b.right - density, b.bottom - density)
        // Darker at the top edge: reads as recessed, the gloss turned inside out.
        fill.shader = LinearGradient(0f, rect.top, 0f, rect.bottom,
            if (dark) intArrayOf(0xFF050505.toInt(), 0xFF141414.toInt())
            else      intArrayOf(0xFFE6E6E6.toInt(), 0xFFFFFFFF.toInt()),
            null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rect, r, r, fill)
        rim.strokeWidth = if (focused) 2 * density else density
        rim.color = when {
            focused -> 0xFF33B5E5.toInt()
            dark    -> 0xFF3A3A3A.toInt()
            else    -> 0xFFB4B4B4.toInt()
        }
        canvas.drawRoundRect(rect, r, r, rim)
    }

    override fun isStateful() = true
    override fun onStateChange(state: IntArray): Boolean {
        val f = state.contains(android.R.attr.state_focused)
        if (f == focused) return false
        focused = f
        invalidateSelf()
        return true
    }
    override fun getPadding(padding: Rect): Boolean {
        val h = (10 * density).toInt(); val v = (8 * density).toInt()
        padding.set(h, v, h, v)
        return true
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/**
 * List selector: Holo blue with the gloss split when pressed, a blue rim on a
 * faint blue wash when focused (D-pad), nothing otherwise.
 */
private class RowDrawable(private val dark: Boolean, private val density: Float) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private var pressed = false
    private var focused = false

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (pressed) {
            paint.shader = LinearGradient(0f, b.top.toFloat(), 0f, b.bottom.toFloat(),
                intArrayOf(0xCC8FDBF7.toInt(), 0xCC5CC6EE.toInt(), 0xCC33B5E5.toInt(), 0xCC2A9FCB.toInt()),
                floatArrayOf(0f, 0.5f, 0.5f, 1f), Shader.TileMode.CLAMP)
            canvas.drawRect(b, paint)
        } else if (focused) {
            paint.shader = null
            paint.color = if (dark) 0x3033B5E5 else 0x2633B5E5
            canvas.drawRect(b, paint)
            rim.color = 0xFF33B5E5.toInt()
            rim.strokeWidth = 2 * density
            canvas.drawRect(b.left + density, b.top + density, b.right - density, b.bottom - density, rim)
        }
    }

    override fun isStateful() = true
    override fun onStateChange(state: IntArray): Boolean {
        val p = state.contains(android.R.attr.state_pressed)
        val f = state.contains(android.R.attr.state_focused) ||
                state.contains(android.R.attr.state_selected)
        if (p == pressed && f == focused) return false
        pressed = p; focused = f
        invalidateSelf()
        return true
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** A magnifying glass, in the secondary text colour. */
private class SearchIconDrawable(private val color: Int, private val density: Float) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    override fun draw(canvas: Canvas) {
        val b = bounds
        val s = minOf(b.width(), b.height()).toFloat()
        paint.color = color
        paint.strokeWidth = 2.2f * density
        val cx = b.left + s * 0.42f; val cy = b.top + s * 0.42f; val r = s * 0.28f
        canvas.drawCircle(cx, cy, r, paint)
        val k = 0.7071f * r
        canvas.drawLine(cx + k, cy + k, b.left + s * 0.9f, b.top + s * 0.9f, paint)
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Row icons: a Holo-blue folder, a page with a folded corner, or an up arrow. */
private class IconDrawable(private val dark: Boolean, private val density: Float) : Drawable() {
    companion object { const val FOLDER = 0; const val FILE = 1; const val UP = 2 }
    var kind = FILE
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val path = Path()

    override fun draw(canvas: Canvas) {
        val b = bounds
        val s = minOf(b.width(), b.height()).toFloat()
        val x = b.left.toFloat(); val y = b.top.toFloat()
        edge.strokeWidth = 1.5f * density
        when (kind) {
            FOLDER -> {
                // Tab, then body, with the button gloss's top-light.
                fill.shader = LinearGradient(0f, y + s * 0.2f, 0f, y + s * 0.9f,
                    0xFF7FD0F0.toInt(), 0xFF2A9FCB.toInt(), Shader.TileMode.CLAMP)
                path.reset()
                path.moveTo(x + s * 0.05f, y + s * 0.22f)
                path.lineTo(x + s * 0.40f, y + s * 0.22f)
                path.lineTo(x + s * 0.48f, y + s * 0.32f)
                path.lineTo(x + s * 0.95f, y + s * 0.32f)
                path.lineTo(x + s * 0.95f, y + s * 0.88f)
                path.lineTo(x + s * 0.05f, y + s * 0.88f)
                path.close()
                canvas.drawPath(path, fill)
                edge.color = 0xFF1C7FA6.toInt()
                canvas.drawPath(path, edge)
            }
            FILE -> {
                val fold = s * 0.28f
                fill.shader = LinearGradient(0f, y, 0f, y + s,
                    if (dark) 0xFF4A4A4A.toInt() else 0xFFFFFFFF.toInt(),
                    if (dark) 0xFF262626.toInt() else 0xFFE2E2E2.toInt(), Shader.TileMode.CLAMP)
                path.reset()
                path.moveTo(x + s * 0.18f, y + s * 0.05f)
                path.lineTo(x + s * 0.82f - fold, y + s * 0.05f)
                path.lineTo(x + s * 0.82f, y + s * 0.05f + fold)
                path.lineTo(x + s * 0.82f, y + s * 0.95f)
                path.lineTo(x + s * 0.18f, y + s * 0.95f)
                path.close()
                canvas.drawPath(path, fill)
                edge.color = 0xFF33B5E5.toInt()
                canvas.drawPath(path, edge)
                canvas.drawLine(x + s * 0.82f - fold, y + s * 0.05f,
                                x + s * 0.82f - fold, y + s * 0.05f + fold, edge)
                canvas.drawLine(x + s * 0.82f - fold, y + s * 0.05f + fold,
                                x + s * 0.82f, y + s * 0.05f + fold, edge)
            }
            else -> {
                edge.color = 0xFF33B5E5.toInt()
                edge.strokeWidth = 2.2f * density
                val cx = x + s * 0.5f
                canvas.drawLine(cx, y + s * 0.85f, cx, y + s * 0.18f, edge)
                canvas.drawLine(cx, y + s * 0.18f, x + s * 0.22f, y + s * 0.46f, edge)
                canvas.drawLine(cx, y + s * 0.18f, x + s * 0.78f, y + s * 0.46f, edge)
            }
        }
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
