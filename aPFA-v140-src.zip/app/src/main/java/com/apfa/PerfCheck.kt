package com.apfa

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.UnderlineSpan
import android.util.Log
import java.io.File

/**
 * Things on the device that hold aPFA below full speed, checked from the setup
 * screen. Everything here is readable by an ordinary app: no root, no ADB.
 *
 * What it deliberately can't do is switch GOS off. Disabling another system
 * package is a shell-user action (`pm disable-user`), and no runtime permission
 * or consent dialog grants it to an app; see GOS-FREQUENCY-CAP-FINDINGS-2026-09-13.md.
 * The best an app can do is send the user to GOS's App info (Force stop /
 * Disable, where One UI offers them) and hand over the exact ADB commands.
 */
class PerfIssue(
    val key: String,
    val title: String,
    val detail: CharSequence,
    val actions: List<Pair<String, (Activity) -> Unit>> = emptyList(),
)

object PerfCheck {
    // Both were disabled together when the S22 Ultra's cap lifted; which one
    // enforces it was never split out, so both are reported.
    val GOS_PACKAGES = listOf(
        "com.samsung.android.game.gos",
        "com.samsung.android.game.gametools",
    )

    /**
     * [cpuMask] is the Core Affinity setting (0 = Auto), so the clock check
     * looks at the core the engine will actually run on. [coldStart] is true
     * until the first playback of this process: a cap seen then can't be heat
     * aPFA produced, so the message says it is throttling or an OEM cap.
     */
    fun scan(ctx: Context, cpuMask: Long, coldStart: Boolean): List<PerfIssue> {
        val out = ArrayList<PerfIssue>()
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val pkg = ctx.packageName

        if (Build.VERSION.SDK_INT >= 21 && pm.isPowerSaveMode) {
            val msg = SpannableStringBuilder(
                "aPFA has detected that a battery saver is enabled, performance will ")
            val start = msg.length
            msg.append("NOT BE ACCURATE")
            msg.setSpan(UnderlineSpan(), start, msg.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            msg.append(" unless you disable battery saver. Either disable it from " +
                       "your notification center, or open Settings.")
            out += PerfIssue("powersave", "Battery saver is on", msg,
                listOf("Open settings" to { a ->
                    open(a, if (Build.VERSION.SDK_INT >= 22)
                                Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
                            else Intent(Settings.ACTION_SETTINGS))
                }))
        }

        // A foreground app isn't throttled by Doze, but a big load runs for
        // minutes and people switch away mid-load; while aPFA is in the
        // background an Optimized or Restricted app can be frozen by One UI.
        // Restricted implies not-ignoring too, so it replaces the Optimized warning.
        val restricted = Build.VERSION.SDK_INT >= 28 &&
            (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).isBackgroundRestricted
        val optimized = Build.VERSION.SDK_INT >= 23 && !pm.isIgnoringBatteryOptimizations(pkg)
        if (restricted || optimized) {
            val state = if (restricted) "restricted" else "optimized"
            out += PerfIssue("battery-$state",
                "Battery usage is ${state.replaceFirstChar { it.uppercase() }}",
                "aPFA has detected that the app is in an $state battery state, " +
                "performance will likely not be accurate, go to App Info or open " +
                "settings to set the performance to \"Unrestricted\".",
                listOf(
                    "App Info" to { a -> openAppInfo(a, pkg) },
                    "Open settings" to { a ->
                        open(a, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    },
                ))
        }

        if (Build.VERSION.SDK_INT >= 29 &&
            pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_MODERATE) {
            out += PerfIssue("thermal", "The phone is running hot",
                "Android reports thermal throttling. Clocks will stay reduced " +
                "until the phone cools down; let it rest before playing.")
        }

        val gosLive = GOS_PACKAGES.filter { isEnabled(ctx, it) }

        val cpus = engineCpus(cpuMask)
        val caps = clockCaps(cpus)
        if (caps.isNotEmpty()) {
            val t = coreThermal(cpus)
            out += PerfIssue("clockcap",
                "CPU clocks are capped" + (t.tempC?.let { " [%dC]".format(it) } ?: ""),
                caps.joinToString("\n") + "\n\n" +
                (if (coldStart)
                     "aPFA found this on a cold start, before it had played " +
                     "anything, so your phone is either throttling or there is " +
                     "an OEM cap on its frequencies.\n\n"
                 else "") +
                (if (gosLive.isNotEmpty())
                     "GOS is running, which is the usual cause on Samsung phones.\n\n"
                 else "") +
                thermalVerdict(t) +
                androidThermal(pm))
        }

        if (gosLive.isNotEmpty()) {
            val cmds = gosLive.joinToString("\n") { "adb shell pm disable-user --user 0 $it" }
            out += PerfIssue("gos", "Samsung GOS is active",
                "aPFA has detected that Samsung Game Optimizer Service is " +
                "present, performance will likely not be accurate, please run " +
                "the following commands below to disable GoS, or copy the " +
                "command to your clipboard.\n\n" + cmds,
                listOf(
                    "App info" to { a -> openAppInfo(a, gosLive.first()) },
                    "Copy commands" to { a -> copy(a, cmds) },
                ))
        }
        return out
    }

    private fun isEnabled(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getApplicationInfo(pkg, 0).enabled
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    private const val CPU_DIR = "/sys/devices/system/cpu"

    /**
     * The cores the engine runs on: the Core Affinity selection, or with Auto
     * the one engine.cpp's chooseBigCore() picks — highest cpuinfo_max_freq,
     * ties to the highest-numbered core.
     */
    private fun engineCpus(cpuMask: Long): List<Int> {
        val all = (File(CPU_DIR).listFiles { f -> f.name.matches(Regex("cpu[0-9]+")) }
                   ?: return emptyList())
            .mapNotNull { it.name.substring(3).toIntOrNull() }
            .sorted()
        if (cpuMask != 0L) return all.filter { it < 64 && ((cpuMask shr it) and 1L) == 1L }
        var best = -1; var bestKHz = 0L
        for (c in all) {
            val khz = readLong(File("$CPU_DIR/cpu$c/cpufreq/cpuinfo_max_freq")) ?: continue
            if (khz >= bestKHz) { best = c; bestKHz = khz }
        }
        return if (best >= 0) listOf(best) else emptyList()
    }

    /** One line per engine core whose live ceiling sits below its rated max. */
    private fun clockCaps(cpus: List<Int>): List<String> = cpus.mapNotNull { c ->
        val d = File("$CPU_DIR/cpu$c/cpufreq")
        val cur = readLong(File(d, "scaling_max_freq")) ?: return@mapNotNull null
        val max = readLong(File(d, "cpuinfo_max_freq")) ?: return@mapNotNull null
        if (cur >= max) return@mapNotNull null
        "cpu%d: %.1f of %.1f MHz (%d%%)".format(c, cur / 1000.0, max / 1000.0, cur * 100 / max)
    }

    /**
     * What the kernel says about the engine core's temperature limits.
     *
     * [throttleC] is the trip point bound to that core's cpufreq cooling
     * device: the temperature at which the KERNEL starts cutting its clock.
     * [shutdownC] is the same sensor's "critical" trip — the phone powering
     * off, which is roughly where the SoC's Tj max sits; never reported as a
     * throttle point. [coolingActive] says whether that cooling device is
     * cutting the clock right now.
     *
     * None of it covers userspace throttling. Samsung's thermal manager writes
     * scaling_max_freq itself, registers no cooling device, and acts at
     * temperatures it doesn't publish (measured on an S22 Ultra: the cap
     * stepped down under load and released at ~43-45 C, far below any trip).
     */
    class CoreThermal(val tempC: Int?, val sensor: String?, val throttleC: Int?,
                      val shutdownC: Int?, val coolingActive: Boolean?)

    private const val THERMAL_DIR = "/sys/class/thermal"

    // The throttle point quoted when the kernel doesn't publish one for the
    // engine core (and Samsung never does — its thermal manager keeps its
    // own). A general figure, not this phone's, set low on purpose: CPU
    // throttling starts somewhere between the 70s and mid 90s C across phone
    // SoCs, and erring early beats telling someone a throttled core is fine.
    // Deliberately nowhere near the shutdown point.
    private const val DEFAULT_THROTTLE_C = 65

    private fun coreThermal(cpus: List<Int>): CoreThermal {
        // The cpufreq cooling devices that throttle the engine's cluster(s).
        // Named after the policy's CPU: "thermal-cpufreq-7", "cpufreq-cpu7".
        val related = HashSet<Int>()
        for (c in cpus) {
            related += c
            File("$CPU_DIR/cpu$c/cpufreq/related_cpus").readTextOrNull()?.trim()
                ?.split(Regex("\\s+"))?.mapNotNull { it.toIntOrNull() }?.let { related += it }
        }
        val cdevState = HashMap<String, Long>()   // canonical path -> cur_state
        File(THERMAL_DIR).listFiles { f -> f.name.startsWith("cooling_device") }?.forEach { d ->
            val type = File(d, "type").readTextOrNull()?.trim()?.lowercase() ?: return@forEach
            if (!type.contains("cpufreq")) return@forEach
            val n = Regex("(\\d+)$").find(type)?.groupValues?.get(1)?.toIntOrNull() ?: return@forEach
            if (n in related) cdevState[canon(d)] = readLong(File(d, "cur_state")) ?: 0L
        }

        // Thermal zones bound to those devices, and the trip each binding uses.
        var best: CoreThermal? = null
        val zones = File(THERMAL_DIR).listFiles { f -> f.name.startsWith("thermal_zone") }
            ?: return CoreThermal(null, null, null, null, null)
        if (cdevState.isNotEmpty()) for (z in zones) {
            z.listFiles { f -> f.name.matches(Regex("cdev[0-9]+")) }?.forEach { link ->
                val state = cdevState[canon(link)] ?: return@forEach
                val trip = readLong(File(z, link.name + "_trip_point"))?.toInt() ?: return@forEach
                val tripC = celsius(readLong(File(z, "trip_point_${trip}_temp"))) ?: return@forEach
                if (tripC < 40) return@forEach      // fan curves and placeholder trips
                if (best?.throttleC?.let { tripC >= it } == true) return@forEach
                best = CoreThermal(
                    celsius(readLong(File(z, "temp"))),
                    File(z, "type").readTextOrNull()?.trim(),
                    tripC, criticalTrip(z), state > 0)
            }
        }
        best?.let { return it }

        // Nothing bound (or not readable): no throttle point, but still the
        // hottest CPU sensor for the title. Zone names are vendor-specific
        // ("cpu-1-2-usr", "cpuss-0", "BIG", "mtktscpu").
        var hot: File? = null; var hotC = Int.MIN_VALUE
        for (z in zones) {
            val type = File(z, "type").readTextOrNull()?.trim()?.lowercase() ?: continue
            if (!(type.contains("cpu") || type == "big" || type == "mid" || type == "little") ||
                type.contains("gpu")) continue
            val c = celsius(readLong(File(z, "temp"))) ?: continue
            if (c > hotC) { hot = z; hotC = c }
        }
        val z = hot ?: return CoreThermal(null, null, null, null, null)
        return CoreThermal(hotC, File(z, "type").readTextOrNull()?.trim(), null, criticalTrip(z), null)
    }

    private fun criticalTrip(z: File): Int? =
        z.listFiles { f -> f.name.matches(Regex("trip_point_[0-9]+_type")) }
            ?.filter { it.readTextOrNull()?.trim()?.lowercase() == "critical" }
            ?.mapNotNull { celsius(readLong(File(z, it.name.replace("_type", "_temp")))) }
            ?.minOrNull()

    private fun canon(f: File): String = try { f.canonicalPath } catch (e: Exception) { f.absolutePath }

    private fun thermalVerdict(t: CoreThermal): String {
        val samsung = Build.MANUFACTURER.equals("samsung", ignoreCase = true)
        val shutdown = t.shutdownC?.let { " The phone shuts itself down at ${it}C." } ?: ""
        if (t.throttleC == null) {
            return "If your temperatures are above ${DEFAULT_THROTTLE_C}C then you're " +
                "throttling! That's a general, cautious figure: this phone doesn't " +
                "publish its own, and many phone chips start cutting clocks around there." +
                shutdown
        }
        val sb = StringBuilder(
            "If your temperatures are above ${t.throttleC}C then you're throttling! " +
            "That is where the kernel starts cutting this core" +
            (t.sensor?.let { " (sensor: $it)" } ?: "") + ".")
        sb.append(shutdown)
        // Below the kernel's point and its cooling device idle: the kernel
        // didn't set this cap, so something in userspace did.
        if (t.coolingActive == false && t.tempC != null && t.tempC < t.throttleC) {
            sb.append(" It is ${t.tempC}C and the kernel isn't throttling, so this cap " +
                      "was set by software" +
                      (if (samsung) " (Samsung's thermal manager or GOS)." else "."))
        }
        return sb.toString()
    }

    /**
     * Android's own view, where it has one: thermal status (API 29) and the
     * headroom forecast (API 30), where 100% is Android's "severe" point.
     * On Samsung both stayed at "none" through a GOS cap, so a quiet status
     * says the cap is policy, not heat.
     */
    private fun androidThermal(pm: PowerManager): String {
        if (Build.VERSION.SDK_INT < 29) return ""
        val names = arrayOf("none", "light", "moderate", "severe", "critical", "emergency", "shutdown")
        val st = pm.currentThermalStatus
        val sb = StringBuilder("\n\nAndroid's thermal status: " + (names.getOrNull(st) ?: "$st"))
        if (Build.VERSION.SDK_INT >= 30) headroom(pm)?.let {
            sb.append(" (%d%% of the way to severe throttling)".format((it * 100).toInt()))
        }
        return sb.append(".").toString()
    }

    // API 30; isolated for the Dalvik verifier. NaN when unsupported or
    // asked again within a second, so treat it as optional.
    @android.annotation.TargetApi(30)
    private fun headroom(pm: PowerManager): Float? = try {
        pm.getThermalHeadroom(0).takeIf { !it.isNaN() }
    } catch (e: Throwable) { null }

    // Thermal zones report millidegrees; a few report whole degrees.
    private fun celsius(raw: Long?): Int? {
        val v = raw ?: return null
        val c = if (v >= 1000 || v <= -1000) (v / 1000).toInt() else v.toInt()
        return if (c in 1..150) c else null
    }

    private fun readLong(f: File): Long? = f.readTextOrNull()?.trim()?.toLongOrNull()

    private fun File.readTextOrNull(): String? = try { readText() } catch (e: Exception) { null }

    private fun openAppInfo(a: Activity, pkg: String) =
        open(a, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))

    private fun open(a: Activity, vararg intents: Intent) {
        for (i in intents) {
            try { a.startActivity(i); return } catch (e: Exception) {
                Log.w("aPFA", "perfcheck: ${i.action} not handled", e)
            }
        }
    }

    private fun copy(a: Activity, text: String) {
        if (Build.VERSION.SDK_INT < 11) return
        val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("aPFA GOS commands", text))
        android.widget.Toast.makeText(a, "Copied", android.widget.Toast.LENGTH_SHORT).show()
    }
}
