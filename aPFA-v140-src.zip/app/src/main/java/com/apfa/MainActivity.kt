package com.apfa

import android.annotation.TargetApi
import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * aPFA setup screen.
 *
 * Pure UI shell — picks the MIDI + soundfont and captures the Voice Count and
 * Note Speed settings. Settings and the chosen soundfont persist across
 * launches via SharedPreferences. The native engine (libapfa.so) does the work.
 */
class MainActivity : Activity() {

    companion object {
        init {
            // Load BASS + BASSMIDI first so libapfa.so resolves them.
            System.loadLibrary("bass")
            System.loadLibrary("bassmidi")
            System.loadLibrary("apfa")
        }
        private const val REQ_MIDI = 1
        private const val REQ_SOUNDFONT = 2
        private const val REQ_BG_IMAGE = 3
        private const val REQ_EXPORT_PROFILE = 4
        private const val REQ_IMPORT_PROFILE = 5
        private const val REQ_STORAGE_PERM = 100
        private const val REQ_ALL_FILES_PERM = 101

        // Setup-screen geometry. The SF button (mid-left) and the settings panel
        // (bottom-right) share the same band of screen, so the SF label's width
        // budget is derived from these — keep buildSetupScreen() and
        // sfButtonLabel() reading the same numbers. The panel sits flush in the
        // bottom-right corner, so no margin is counted on its side.
        private const val EDGE_MARGIN_DP = 20
        private const val PANEL_WIDTH_DP = 280
        // Breathing room left between the SF text and the panel's left edge.
        private const val SF_GAP_DP = 16
        // Floor for the Play MIDI / SF column; both stretch to the wider label.
        // 85% of the old 110, with the rest of the buttons (UiTheme.gloss).
        private const val LEFT_BUTTON_MIN_DP = 94

        private const val SF_PREFIX = "SF: "
        private const val SF_ELLIPSIS = "..."

        // Pagefile Location radio ids. RadioGroup.check() needs real ids and
        // View.generateViewId() is API 17+, so they're fixed — they only have to
        // be unique inside that group.
        private const val ID_LOC_INTERNAL = 1
        private const val ID_LOC_SD = 2
        // GFX > Theme radio ids, same reasoning.
        private const val ID_THEME_SYSTEM = 11
        private const val ID_THEME_LIGHT = 12
        private const val ID_THEME_DARK = 13

        // Advanced Settings tabs.
        private const val TAB_MAIN = 0
        private const val TAB_SYNTH = 1
        private const val TAB_GFX = 2

        // Synth > Sample Rate. What BASSMIDI renders at; BASS resamples it to
        // the output device, so even 4 kHz plays on any phone (synth.cpp).
        private const val DEFAULT_SAMPLE_RATE = 44100
        private val SAMPLE_RATES = intArrayOf(48000, 44100, 32000, 22050, 16000, 11025, 8000, 4000)

        // GFX > Resolution: common phone panels, landscape, smallest first.
        // The playback surface renders at exactly this size and the display
        // hardware scales it to the screen, so it behaves like that phone.
        private class Res(val w: Int, val h: Int, val name: String)
        private val RESOLUTIONS = arrayOf(
            Res(800, 480, "WVGA"),
            Res(854, 480, "FWVGA"),
            Res(960, 540, "qHD"),
            Res(1024, 600, "WSVGA"),
            Res(1280, 720, "HD"),
            Res(1440, 720, "HD+ 18:9"),
            Res(1520, 720, "HD+ 19:9"),
            Res(1600, 720, "HD+ 20:9"),
            Res(1920, 1080, "Full HD"),
            Res(2160, 1080, "FHD+ 18:9"),
            Res(2280, 1080, "FHD+ 19:9"),
            Res(2340, 1080, "FHD+ 19.5:9"),
            Res(2400, 1080, "FHD+ 20:9"),
            Res(2520, 1080, "FHD+ 21:9"),
            Res(2560, 1440, "QHD"),
            Res(2960, 1440, "QHD+ 18.5:9"),
            Res(3040, 1440, "QHD+ 19:9"),
            Res(3088, 1440, "QHD+ 19.3:9"),
            Res(3200, 1440, "QHD+ 20:9"),
            Res(3840, 2160, "4K UHD"))

        // PerfCheck issue keys already shown this process.
        private val perfWarned = HashSet<String>()
        // False until the first Play of this process. A clock cap seen before
        // then is a cold-start cap: not heat from aPFA's own run.
        private var playedThisProcess = false
        private var cacheSwept = false
        // Set just before a theme change restarts the activity, so the new
        // instance re-opens Advanced Settings on GFX where the user left it.
        private var reopenGfx = false
    }

    // Setup state — persisted across launches, handed to the engine on playback.
    private var midiUri: Uri? = null
    private var soundfontUri: Uri? = null
    // The soundfont's name as it was when picked. Kept because once a grant
    // is gone the provider won't answer a name query, and the button would
    // otherwise show a bare document id.
    private var soundfontName: String? = null
    private var voiceCount = 250
    private var noteSpeed = 0.05f
    // Bitmask of CPUs the engine is allowed to use. 0 = "Auto" (engine picks the
    // fastest core itself, see chooseBigCore in engine.cpp).
    private var cpuMask: Long = 0L
    // Use the ES2 "Legacy Renderer (GLES 2.0)" instead of the default ES3
    // renderer. Required on ES2-only GPUs (e.g. Mali-400 / MT6570) that cannot
    // create an ES3 context.
    private var legacyRenderer = false
    // Whether THIS process is 32-bit, which is the only case where the pool is
    // ever split into sub-2 GB files (streamer.cpp, poolFileBytes()). The APK
    // ships both ABIs, so a 64-bit device runs a 64-bit process and the device
    // capability is a faithful proxy; anything before API 21 is 32-bit outright.
    private val is32BitProcess: Boolean
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
                    Build.SUPPORTED_64_BIT_ABIS.isEmpty()
                else true

    // "Chunked Disk Paging" (Advanced Settings): allow the chunked on-disk
    // pagefile sort for MIDIs whose load transient exceeds RAM (~80M+ notes).
    // Streaming itself stays automatic either way (RAM-fit prediction / crash
    // marker); without this, beyond-ceiling MIDIs are refused with a message
    // pointing here. Pref/extra key stays "diskStreaming" for settings compat.
    private var chunkedStreaming = false
    // "Pagefile Location = SD Card" (Advanced Settings): put the streaming pool
    // file on the removable card instead of internal storage. Only offered where
    // it can work — see SdCard.unavailableReason. Pref/extra key stays
    // "sdPagefile" for settings compat.
    private var sdPagefile = false
    // Background color in PFA BGR format (R=bit0, G=bit8, B=bit16). Default = PFA's 0x464646.
    private var bgColor: Int = 0x00464646
    // Optional background image path (in filesDir). When set, it overrides bgColor
    // during playback. Cleared when the user picks a solid colour instead.
    private var bgImagePath: String? = null
    // Profile waiting to be written out by the export pick's result, and the
    // file name offered for it.
    private var pendingExport: JSONObject? = null
    private var pendingExportFile = ""

    // "Synth" tab. Volume is BASSMIDI's output level in percent; sample rate
    // is what it renders at.
    private var synthVolume = 100
    private var sampleRate = DEFAULT_SAMPLE_RATE
    // "GFX" tab. Render resolution, 0x0 = the screen's own. Theme is
    // UiTheme.MODE_*; System follows the OS, and no mode at all means light.
    private var resW = 0
    private var resH = 0
    private var themeMode = UiTheme.MODE_SYSTEM
    // "Main" tab, playback behaviour: the stage + log line under the loading
    // percentage, starting with the action bar hidden, starting paused.
    private var verboseLoading = false
    private var startFullscreen = false
    private var pauseOnLoad = false
    // The mode this instance was themed with. Fixed at onCreate: a change
    // restarts the activity (system changes via uiMode, overrides via
    // restartForTheme()).
    private var dark = false

    private lateinit var midiButton: Button
    private lateinit var soundfontButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        // Theme before super.onCreate and before any view: every widget and
        // dialog below takes its colours from it.
        themeMode = getPreferences(MODE_PRIVATE).getInt("themeMode", themeMode)
        dark = UiTheme.isDark(this, themeMode)
        setTheme(UiTheme.activityTheme(dark))
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        loadSettings()
        setContentView(buildSetupScreen())
        // After setContentView: touching the decor view any earlier would
        // lock the window features before FEATURE_NO_TITLE is requested.
        if (!dark && Build.VERSION.SDK_INT >= 29) UiTheme.blockForceDark(this)
        if (reopenGfx) {
            reopenGfx = false
            showAdvancedSettingsDialog(TAB_GFX)
        }
        ensureStoragePermission()
        if (savedInstanceState == null) {
            pruneGrants()
            warnIfSoundfontMissing()
        }
        // Reclaim any multi-GB pagefile a previous run died holding. Touches
        // the card, so keep it off the UI thread.
        Thread { SdCard.sweep(this) }.start()
        // Copies a killed playback never got to delete. Once per process: a
        // fresh process has no engine that could still be using them.
        if (!cacheSwept) {
            cacheSwept = true
            PlaybackActivity.clearCopies(cacheDir)
        }
    }

    // Re-scanned on every return to this screen, so fixing something in Settings
    // and coming back clears it. Only a NEW problem re-opens the dialog; the
    // shown set lives for the process, so a reboot (which re-arms GOS) warns again.
    private var perfDialog: AlertDialog? = null

    override fun onResume() {
        super.onResume()
        val issues = PerfCheck.scan(this, cpuMask, coldStart = !playedThisProcess)
        val keys = issues.map { it.key }.toSet()
        perfWarned.retainAll(keys)   // a cleared problem warns again if it returns
        if (keys.all { it in perfWarned }) return
        perfWarned += keys
        perfDialog?.dismiss()
        perfDialog = showPerfIssues(issues)
    }

    private fun showPerfIssues(issues: List<PerfIssue>): AlertDialog {
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(20), dp(8), dp(20), dp(8))
        for (issue in issues) {
            val title = TextView(this)
            title.text = issue.title
            title.textSize = 16f
            title.typeface = android.graphics.Typeface.DEFAULT_BOLD
            title.setPadding(0, dp(10), 0, dp(2))
            list.addView(title)
            val detail = TextView(this)
            detail.text = issue.detail
            detail.textSize = 14f
            if (Build.VERSION.SDK_INT >= 11) detail.setTextIsSelectable(true)
            list.addView(detail)
            if (issue.actions.isNotEmpty()) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                for ((label, act) in issue.actions) {
                    val b = gloss(Button(this))
                    b.text = label
                    b.setOnClickListener { act(this) }
                    row.addView(b)
                }
                list.addView(row)
            }
        }
        val scroll = ScrollView(this)
        scroll.addView(list)
        return AlertDialog.Builder(this)
            .setTitle("Warning:")
            .setView(scroll)
            .setPositiveButton("OK", null)
            .show()
    }

    // Old devices (and some OEM pickers, e.g. Huawei EMUI) return file:// URIs from
    // the document picker. Opening those reads the raw /storage path, which needs
    // READ_EXTERNAL_STORAGE. Modern phones (API 33+) always get content:// — no
    // permission needed, and the permission no longer exists — so we only ask on 23..32.
    //
    // Export Profile writes by path through aPFA's browser, which on 23..29
    // also needs WRITE_EXTERNAL_STORAGE (from 30, All files access covers it).
    // Both sit in the one Storage permission group, so it is still one prompt.
    private fun ensureStoragePermission() {
        if (Build.VERSION.SDK_INT in 23..32) {
            val perms = if (Build.VERSION.SDK_INT <= 29)
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)
            else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), REQ_STORAGE_PERM)
        }
    }

    @Suppress("DEPRECATION")   // setBackgroundDrawable: setBackground is API 16
    private fun buildSetupScreen(): View {
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT
        val root = FrameLayout(this)

        // --- background (apfa-wp.jpg from assets; dark fallback if absent) ---
        val bg = ImageView(this)
        bg.scaleType = ImageView.ScaleType.CENTER_CROP
        bg.layoutParams = FrameLayout.LayoutParams(mp, mp)
        val bgBitmap = loadAsset("apfa-wp.jpg")
        if (bgBitmap != null) bg.setImageBitmap(bgBitmap)
        else bg.setBackgroundColor(Color.rgb(18, 18, 24))
        root.addView(bg)

        // --- top-left: logo + version ---
        val topLeft = LinearLayout(this)
        topLeft.orientation = LinearLayout.HORIZONTAL
        topLeft.gravity = Gravity.CENTER_VERTICAL
        topLeft.layoutParams = FrameLayout.LayoutParams(wc, wc).apply {
            gravity = Gravity.TOP or Gravity.START
            setMargins(dp(20), dp(20), 0, 0)
        }
        loadAsset("aPFAlogo.png")?.let { logo ->
            val iv = ImageView(this)
            iv.setImageBitmap(logo)
            iv.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
            topLeft.addView(iv)
        }
        // Version on a plate of Aero glass (paneaero.png, from mini8s), drawn
        // silver with a black outline — the same in Light and Dark.
        // ES2/ES3 are now one build (renderer chosen by the Legacy toggle), so the
        // old "-ES2" fork suffix is gone.
        val plate = FrameLayout(this)
        loadAsset("paneaero.png")?.let { plate.setBackgroundDrawable(PaneDrawable(it)) }
        plate.setPadding(dp(10), dp(3), dp(10), dp(3))
        plate.addView(SilverText(this, "aPFA v" + appVersion(), 20f))
        topLeft.addView(plate, LinearLayout.LayoutParams(wc, wc).apply { leftMargin = dp(12) })
        root.addView(topLeft)

        // --- bottom-left: byline ---
        val byline = TextView(this)
        byline.text = "By Starzainia and HexagonMIDIs!"
        byline.setTextColor(Color.WHITE)
        byline.textSize = 16f
        byline.setShadowLayer(4f, 0f, 2f, Color.BLACK)
        root.addView(byline, FrameLayout.LayoutParams(wc, wc).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            setMargins(dp(20), 0, 0, dp(20))
        })

        // --- top-right: Core Affinity gear ---
        val gear = gloss(Button(this)).apply {
            text = "⚙"
            textSize = 22f
            contentDescription = "Core Affinity"
            setOnClickListener { showCoreAffinityDialog() }
        }
        root.addView(gear, FrameLayout.LayoutParams(wc, wc).apply {
            gravity = Gravity.TOP or Gravity.END
            setMargins(0, dp(20), dp(20), 0)
        })

        // --- mid-left: actions ---
        val midLeft = LinearLayout(this)
        midLeft.orientation = LinearLayout.VERTICAL
        midLeft.layoutParams = FrameLayout.LayoutParams(wc, wc).apply {
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            setMargins(dp(EDGE_MARGIN_DP), 0, 0, 0)
        }
        midiButton = gloss(Button(this))
        midiButton.text = "Play MIDI"
        midiButton.setOnClickListener { pickFile(REQ_MIDI) }
        // Both MATCH_PARENT on purpose: when every child matches, the column takes
        // the widest child and stretches the rest to it. Mixing one MATCH_PARENT
        // with a wrap_content sibling is what used to squash "Play MIDI".
        midiButton.minWidth = dp(LEFT_BUTTON_MIN_DP)
        midLeft.addView(midiButton, LinearLayout.LayoutParams(mp, wc))

        // Glossed before the label is sized: sfButtonLabel() measures against
        // the padding the gloss background supplies.
        soundfontButton = gloss(Button(this))
        soundfontButton.text = soundfontUri?.let { sfButtonLabel(it) } ?: "Load Soundfont"
        soundfontButton.setOnClickListener { pickFile(REQ_SOUNDFONT) }
        soundfontButton.minWidth = dp(LEFT_BUTTON_MIN_DP)
        midLeft.addView(soundfontButton, LinearLayout.LayoutParams(mp, wc).apply {
            topMargin = dp(12)
        })
        root.addView(midLeft)

        // --- bottom-right: settings ---
        // No box behind it any more, and no margin: the panel's own corner is
        // the screen's corner, and its padding is all that keeps the controls
        // off the edge.
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(16), dp(12), dp(16), dp(12))
        panel.layoutParams = FrameLayout.LayoutParams(dp(PANEL_WIDTH_DP), wc).apply {
            gravity = Gravity.END or Gravity.BOTTOM
        }

        // --- Background Color button (above Voice slider) ---
        val colorButton = gloss(Button(this))
        colorButton.text = "Background"
        colorButton.setOnClickListener { showBgColorDialog() }
        panel.addView(colorButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(8)
        })

        val voiceLabel = label("Voice Count: $voiceCount")
        panel.addView(voiceLabel)
        val voiceBar = SeekBar(this)
        voiceBar.max = 500
        voiceBar.progress = voiceCount
        voiceBar.setOnSeekBarChangeListener(simpleListener { p ->
            voiceCount = p.coerceAtLeast(1)
            voiceLabel.text = "Voice Count: $voiceCount"
        })
        panel.addView(voiceBar)
        voiceLabel.setOnClickListener { showVoiceCountDialog(voiceLabel, voiceBar) }

        val speedLabel = label("Note Speed: %.3f".format(noteSpeed))
        speedLabel.layoutParams = LinearLayout.LayoutParams(wc, wc).apply { topMargin = dp(10) }
        panel.addView(speedLabel)
        val speedBar = SeekBar(this)
        speedBar.max = 1000                                  // non-linear, 0.05 at the midpoint
        speedBar.progress = progressFromSpeed(noteSpeed)
        speedBar.setOnSeekBarChangeListener(simpleListener { p ->
            noteSpeed = speedFromProgress(p)
            speedLabel.text = "Note Speed: %.3f".format(noteSpeed)
        })
        panel.addView(speedBar)

        // --- Advanced Settings (Main / Synth / GFX) ---
        val advancedButton = gloss(Button(this))
        advancedButton.text = "Advanced Settings"
        advancedButton.setOnClickListener { showAdvancedSettingsDialog() }
        panel.addView(advancedButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(10)
        })

        root.addView(panel)

        return root
    }

    // Same 1..500 range as the slider; anything higher corrects to 500.
    private fun showVoiceCountDialog(voiceLabel: TextView, voiceBar: SeekBar) {
        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_NUMBER
        input.filters = arrayOf(InputFilter.LengthFilter(3))
        input.imeOptions = EditorInfo.IME_ACTION_DONE or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        input.setText(voiceCount.toString())
        input.selectAll()

        fun commit() {
            val v = input.text.toString().toIntOrNull()?.coerceIn(1, voiceBar.max) ?: return
            voiceBar.progress = v
            voiceCount = v
            voiceLabel.text = "Voice Count: $voiceCount"
            saveSettings()
        }

        val box = FrameLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(input)
        val dialog = AlertDialog.Builder(this)
            .setTitle("Voice Count")
            .setView(box)
            .setPositiveButton("OK") { _, _ -> commit() }
            .setNegativeButton("Cancel", null)
            .create()
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { commit(); dialog.dismiss(); true }
            else false
        }
        // STATE_ALWAYS_VISIBLE alone doesn't open it: the field isn't focused yet.
        dialog.setOnShowListener {
            input.requestFocus()
            input.post {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            }
        }
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
        dialog.show()
    }

    // usableSpace = blocks this app can actually write (root-reserved excluded),
    // in binary units like df.
    private fun freeSpaceLabel(dir: File?): String {
        val b = dir?.usableSpace ?: return ""
        val gb = b / 1073741824.0
        val s = if (gb >= 1) "%.2fGB".format(gb) else "%.2fMB".format(b / 1048576.0)
        return " [$s free]"
    }

    // --- Advanced Settings dialog ---------------------------------------------
    // Three tabs, one page each, switched in place under a row of glossy tabs:
    //   Main  — Chunked Disk Paging, and Pagefile Location under it.
    //   Synth — BASSMIDI's volume and sample rate.
    //   GFX   — Legacy Renderer, render resolution, and the Light/Dark override.
    // Only the page scrolls; the tabs stay put, since a landscape phone has
    // barely a dialog's height to spare.
    private fun showAdvancedSettingsDialog(startTab: Int = TAB_MAIN) {
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT

        val outer = LinearLayout(this)
        outer.orientation = LinearLayout.VERTICAL
        outer.setPadding(dp(20), dp(10), dp(20), 0)

        val tabRow = LinearLayout(this)
        tabRow.orientation = LinearLayout.HORIZONTAL
        outer.addView(tabRow, LinearLayout.LayoutParams(mp, wc))

        val body = FrameLayout(this)
        body.setPadding(0, 0, 0, dp(10))
        val scroll = ScrollView(this)
        scroll.addView(body)
        outer.addView(scroll, LinearLayout.LayoutParams(mp, wc).apply { topMargin = dp(8) })

        val dialog = AlertDialog.Builder(this)
            .setTitle("Advanced Settings")
            .setView(outer)
            .setPositiveButton("Done", null)
            .create()

        val pages = arrayOf(buildMainTab(), buildSynthTab(), buildGfxTab(dialog))
        for (p in pages) body.addView(p, FrameLayout.LayoutParams(mp, wc))

        val tabs = ArrayList<Button>()
        fun select(i: Int) {
            for (j in pages.indices) {
                pages[j].visibility = if (j == i) View.VISIBLE else View.GONE
                tabs[j].isSelected = j == i      // GlossDrawable draws selected as pressed-in
            }
            scroll.scrollTo(0, 0)
        }
        for ((i, name) in arrayOf("Main", "Synth", "GFX").withIndex()) {
            val tab = gloss(Button(this))
            tab.text = name
            tab.setOnClickListener { select(i) }
            tabs.add(tab)
            tabRow.addView(tab, LinearLayout.LayoutParams(0, wc, 1f).apply {
                if (i > 0) leftMargin = dp(6)
            })
        }
        select(startTab)
        dialog.show()
    }

    // Section heading inside a tab, in the dialog's own text colour.
    private fun sectionHeader(text: String, top: Int = 12): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 15f
        tv.typeface = android.graphics.Typeface.DEFAULT_BOLD
        themeTextColor()?.let { tv.setTextColor(it) }
        tv.setPadding(0, dp(top), 0, dp(2))
        return tv
    }

    // Small explanatory line under a setting. Mid grey reads on both themes.
    private fun noteText(text: String): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 12f
        tv.setTextColor(Color.GRAY)
        tv.setPadding(0, dp(2), 0, dp(4))
        return tv
    }

    private fun themeTextColor(): android.content.res.ColorStateList? {
        val a = obtainStyledAttributes(intArrayOf(android.R.attr.textColorPrimary))
        try { return a.getColorStateList(0) } finally { a.recycle() }
    }

    // Main: Chunked Disk Paging allows the on-disk chunked pagefile sort for
    // MIDIs too big even for normal (automatic) disk streaming — the one hop
    // between little Timmy and a 12 GB pagefile. Pagefile Location sits under
    // that as Internal / SD Card, for the phones whose internal storage was
    // never going to hold it (SdCard.kt).
    private fun buildMainTab(): View {
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL

        fun toggle(text: String, on: Boolean, set: (Boolean) -> Unit) {
            val box = CheckBox(this)
            box.text = text
            box.isChecked = on
            box.setOnCheckedChangeListener { _, checked -> set(checked); saveSettings() }
            container.addView(box)
        }
        toggle("Verbose Loading Details", verboseLoading) { verboseLoading = it }
        toggle("Always Start Full Screen", startFullscreen) { startFullscreen = it }
        toggle("Always Pause Player on Load", pauseOnLoad) { pauseOnLoad = it }

        val streamBox = CheckBox(this)
        streamBox.text = "Chunked Disk Paging"
        streamBox.isChecked = chunkedStreaming
        streamBox.setOnCheckedChangeListener { _, checked ->
            if (checked && !chunkedStreaming) {
                AlertDialog.Builder(this)
                    .setTitle("Chunked Disk Paging")
                    .setMessage("Sorts a huge MIDI's pagefile in chunks on " +
                                "disk instead of in RAM, so Black MIDIs too " +
                                "big for normal disk streaming can load, " +
                                "the only limit is your free storage.\n\n" +
                                "WARNING: loading such MIDIs can take VERY " +
                                "large amounts of storage, stability issues " +
                                "may occur, and loading times could be very " +
                                "long.\n\n" +
                                // Only on a 32-bit phone, because the pagefile
                                // is only ever split there (streamer.cpp,
                                // poolFileBytes()).
                                (if (is32BitProcess)
                                    "ADDITIONALLY: On this phone (has been " +
                                    "detected to be 32-bit / ARMv7), a MIDI " +
                                    "whose pagefile grows past 2 GB is written " +
                                    "as several files instead of one, because " +
                                    "32-bit Android cannot reach past 2 GB " +
                                    "inside a single file. Instability and a " +
                                    "lack of responsiveness may occur if any " +
                                    "MIDI goes past around 1.5GB streamed " +
                                    "(15M+ notes).\n\n"
                                 else "") +
                                "Are you sure you want to enable this?")
                    .setPositiveButton("Yes") { _, _ ->
                        chunkedStreaming = true
                        saveSettings()
                    }
                    .setNegativeButton("No") { _, _ ->
                        streamBox.isChecked = false
                    }
                    .setOnCancelListener {
                        streamBox.isChecked = false
                    }
                    .show()
            } else if (!checked) {
                chunkedStreaming = false
                saveSettings()
            }
        }
        container.addView(streamBox)

        // --- Pagefile Location (nested under Chunked Disk Paging) ---
        // Where the pagefile is written, rather than whether there is one: the
        // pagefile IS the streaming pool, so this applies to any streaming load
        // — which is why the choice stays live with the box above unticked.
        //
        // SD is offered only where it can actually work, and is otherwise
        // greyed out with the reason spelled out underneath: pre-KitKat (no
        // app-private path on a secondary volume), a 32-bit process (the pool
        // mapping needs 64-bit address space — the reason distinguishes a
        // 32-bit CPU from a 64-bit CPU on a 32-bit ROM, which is what an
        // SD425 phone like the LG X410 actually is), or no card mounted.
        val sdReason = SdCard.unavailableReason(this)

        val locHeader = TextView(this)
        locHeader.text = "Pagefile Location"
        locHeader.textSize = 14f
        // Take the checkboxes' resolved colour instead of guessing at whether
        // this dialog came up light or dark.
        locHeader.setTextColor(streamBox.currentTextColor)
        locHeader.setPadding(dp(32), dp(8), 0, dp(2))
        container.addView(locHeader)

        val locGroup = RadioGroup(this)
        locGroup.orientation = RadioGroup.VERTICAL
        locGroup.setPadding(dp(32), 0, 0, 0)
        val internalRadio = RadioButton(this)
        internalRadio.id = ID_LOC_INTERNAL
        internalRadio.text = "Internal"
        locGroup.addView(internalRadio)
        val sdRadio = RadioButton(this)
        sdRadio.id = ID_LOC_SD
        sdRadio.text = "SD Card"
        sdRadio.isEnabled = sdReason == null
        locGroup.addView(sdRadio)
        container.addView(locGroup)

        val sdNote = TextView(this)
        sdNote.textSize = 12f
        sdNote.setTextColor(Color.GRAY)      // LTGRAY vanishes on a light dialog
        sdNote.setPadding(dp(32), 0, 0, dp(4))
        container.addView(sdNote)

        // The card may have been pulled since the setting was saved — drop it
        // so nothing downstream tries to use a path that isn't there.
        if (sdReason != null && sdPagefile) { sdPagefile = false; saveSettings() }

        // The note doubles as the greyed-out reason, so it tracks the selection.
        fun describeLocation() {
            // Internal loads put the pagefile next to the cached MIDI in cacheDir.
            internalRadio.text = "Internal" + (if (sdPagefile) "" else freeSpaceLabel(cacheDir))
            sdRadio.text = "SD Card" + (if (sdPagefile) freeSpaceLabel(SdCard.cacheDir(this)) else "")
            sdNote.text = when {
                sdReason != null -> sdReason
                sdPagefile -> "Writes the streaming pagefile to " +
                              (SdCard.cacheDir(this)?.absolutePath ?: "the card") +
                              "\nCards are slower than internal storage, so expect " +
                              "more pagefile lag."
                else -> "Writes the streaming pagefile to the app's cache dir on " +
                        "internal storage."
            }
        }

        // Set the starting position before listening, or check() writes the
        // setting straight back on open.
        locGroup.check(if (sdPagefile) ID_LOC_SD else ID_LOC_INTERNAL)
        describeLocation()
        locGroup.setOnCheckedChangeListener { _, checkedId ->
            sdPagefile = checkedId == ID_LOC_SD
            saveSettings()
            describeLocation()
        }
        return container
    }

    // Synth: BASSMIDI's output volume (BASS_ATTRIB_VOL, applied after the
    // limiter) and the rate it renders at. Both take effect on the next Play.
    private fun buildSynthTab(): View {
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL

        val volLabel = sectionHeader("Synth Volume: $synthVolume", 4)
        container.addView(volLabel)
        val volBar = SeekBar(this)
        volBar.max = 100
        volBar.progress = synthVolume
        volBar.setOnSeekBarChangeListener(simpleListener { p ->
            synthVolume = p
            volLabel.text = "Synth Volume: $synthVolume"
        })
        container.addView(volBar)
        container.addView(noteText("100 is full volume (the default)."))

        container.addView(sectionHeader("Sample Rate"))
        val rateButton = gloss(Button(this))
        rateButton.text = rateLabel(sampleRate)
        rateButton.setOnClickListener {
            showSampleRateDialog { rateButton.text = rateLabel(sampleRate) }
        }
        container.addView(rateButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        container.addView(noteText("The rate BASSMIDI renders at. Lower rates take load " +
                                   "off the CPU and sound duller; 44.1 kHz is the default."))
        return container
    }

    // "44.1 kHz", "48 kHz", "11.025 kHz".
    private fun rateLabel(hz: Int): String =
        java.math.BigDecimal(hz).movePointLeft(3).stripTrailingZeros().toPlainString() + " kHz"

    private fun showSampleRateDialog(onPick: () -> Unit) {
        val labels = Array(SAMPLE_RATES.size) { i ->
            rateLabel(SAMPLE_RATES[i]) + if (SAMPLE_RATES[i] == DEFAULT_SAMPLE_RATE) "  (default)" else ""
        }
        AlertDialog.Builder(this)
            .setTitle("Sample Rate")
            .setSingleChoiceItems(labels, SAMPLE_RATES.indexOf(sampleRate)) { d, which ->
                sampleRate = SAMPLE_RATES[which]
                saveSettings()
                onPick()
                d.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // GFX: Legacy Renderer is the ES2 fallback for GPUs (Mali-400 / MT6570)
    // that can't create an ES3 context. Resolution sets the size playback
    // renders at. Theme overrides the system's Light/Dark; changing it
    // restarts this screen, so [owner] is closed first.
    private fun buildGfxTab(owner: AlertDialog): View {
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL

        val legacyBox = CheckBox(this)
        legacyBox.text = "Legacy Renderer (GLES 2.0)"
        legacyBox.isChecked = legacyRenderer
        legacyBox.setOnCheckedChangeListener { _, checked ->
            legacyRenderer = checked
            saveSettings()
        }
        container.addView(legacyBox)

        container.addView(sectionHeader("Resolution"))
        val resButton = gloss(Button(this))
        resButton.text = resolutionLabel()
        resButton.setOnClickListener {
            showResolutionDialog { resButton.text = resolutionLabel() }
        }
        container.addView(resButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        container.addView(noteText("This will change the resolution aPFA renders at, as if " +
                                   "the app were running on a phone with said resolution."))

        container.addView(sectionHeader("Theme"))
        val themeGroup = RadioGroup(this)
        themeGroup.orientation = RadioGroup.VERTICAL
        val sysRadio = RadioButton(this)
        sysRadio.id = ID_THEME_SYSTEM
        sysRadio.text = "System (currently " +
                        (if (UiTheme.systemIsDark(this)) "Dark" else "Light") + ")"
        themeGroup.addView(sysRadio)
        val lightRadio = RadioButton(this)
        lightRadio.id = ID_THEME_LIGHT
        lightRadio.text = "Light"
        themeGroup.addView(lightRadio)
        val darkRadio = RadioButton(this)
        darkRadio.id = ID_THEME_DARK
        darkRadio.text = "Dark"
        themeGroup.addView(darkRadio)
        container.addView(themeGroup)

        // Starting position before listening, as with Pagefile Location.
        themeGroup.check(when (themeMode) {
            UiTheme.MODE_LIGHT -> ID_THEME_LIGHT
            UiTheme.MODE_DARK  -> ID_THEME_DARK
            else               -> ID_THEME_SYSTEM
        })
        themeGroup.setOnCheckedChangeListener { _, checkedId ->
            themeMode = when (checkedId) {
                ID_THEME_LIGHT -> UiTheme.MODE_LIGHT
                ID_THEME_DARK  -> UiTheme.MODE_DARK
                else           -> UiTheme.MODE_SYSTEM
            }
            saveSettings()
            // "System" while the system already matches changes nothing on screen.
            if (UiTheme.isDark(this, themeMode) != dark) {
                owner.dismiss()
                restartForTheme()
            }
        }
        return container
    }

    /**
     * Re-run onCreate under the new theme. A theme can't be swapped under live
     * views, and the setup screen is cheap to rebuild. recreate() is API 11;
     * before that, a fresh instance does the same job.
     */
    private fun restartForTheme() {
        reopenGfx = true
        if (Build.VERSION.SDK_INT >= 11) {
            recreate()
        } else {
            finish()
            startActivity(Intent(this, MainActivity::class.java))
        }
    }

    // Landscape size of the whole panel, for the "Native" entry.
    private fun nativeSize(): Pair<Int, Int> {
        val m = if (Build.VERSION.SDK_INT >= 17) realMetrics() else resources.displayMetrics
        return Pair(maxOf(m.widthPixels, m.heightPixels), minOf(m.widthPixels, m.heightPixels))
    }

    // getRealMetrics is API 17; isolated for the Dalvik verifier.
    @TargetApi(17)
    private fun realMetrics(): android.util.DisplayMetrics {
        val m = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(m)
        return m
    }

    private fun resolutionLabel(): String {
        if (resW <= 0 || resH <= 0) {
            val (w, h) = nativeSize()
            return "Native (${w}x$h)"
        }
        val name = RESOLUTIONS.firstOrNull { it.w == resW && it.h == resH }?.name
        return "${resW}x$resH" + (if (name != null) "  $name" else "")
    }

    private fun showResolutionDialog(onPick: () -> Unit) {
        val (nw, nh) = nativeSize()
        val labels = ArrayList<String>()
        labels.add("Native (${nw}x$nh)  (default)")
        for (r in RESOLUTIONS) {
            // Bigger than the panel still works — it is supersampled down.
            val above = r.w.toLong() * r.h > nw.toLong() * nh
            labels.add("${r.w}x${r.h}  ${r.name}" + if (above) "  (above this screen)" else "")
        }
        val current = RESOLUTIONS.indexOfFirst { it.w == resW && it.h == resH } + 1
        AlertDialog.Builder(this)
            .setTitle("Resolution")
            .setSingleChoiceItems(labels.toTypedArray(), current) { d, which ->
                if (which == 0) { resW = 0; resH = 0 }
                else { resW = RESOLUTIONS[which - 1].w; resH = RESOLUTIONS[which - 1].h }
                saveSettings()
                onPick()
                d.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // --- Note Speed slider: non-linear so the 0.05 default sits at the midpoint ---
    // progress 0..500   -> noteSpeed 0.005..0.05
    // progress 500..1000-> noteSpeed 0.05 ..1.0
    private fun speedFromProgress(p: Int): Float =
        if (p <= 500) 0.005f + (p / 500f) * 0.045f
        else          0.05f + ((p - 500) / 500f) * 0.95f

    private fun progressFromSpeed(s: Float): Int =
        if (s <= 0.05f) (((s - 0.005f) / 0.045f) * 500f).toInt().coerceIn(0, 500)
        else            (500 + ((s - 0.05f) / 0.95f) * 500f).toInt().coerceIn(500, 1000)

    // --- Core Affinity dialog -------------------------------------------------
    // Lists every cpuN dir under /sys/devices/system/cpu with its cpuinfo_max_freq.
    // Multi-select; saves the chosen set as a 64-bit mask. Empty = "Auto".

    private data class CpuRow(val index: Int, val maxKHz: Long)

    private fun readCpuList(): List<CpuRow> {
        val dir = File("/sys/devices/system/cpu")
        val entries = dir.listFiles { f ->
            f.isDirectory && f.name.matches(Regex("cpu[0-9]+"))
        } ?: return emptyList()
        return entries
            .mapNotNull { f ->
                val idx = f.name.substring(3).toIntOrNull() ?: return@mapNotNull null
                val freqFile = File(f, "cpufreq/cpuinfo_max_freq")
                val khz = try {
                    if (freqFile.exists()) freqFile.readText().trim().toLong() else 0L
                } catch (e: Exception) { 0L }
                CpuRow(idx, khz)
            }
            .sortedBy { it.index }
    }

    private fun formatCpuRow(row: CpuRow): String =
        if (row.maxKHz > 0)
            "cpu%d  —  %.2f GHz".format(row.index, row.maxKHz / 1_000_000.0)
        else
            "cpu%d  —  (offline)".format(row.index)

    private fun showCoreAffinityDialog() {
        val cpus = readCpuList()
        if (cpus.isEmpty()) {
            Toast.makeText(this, "No CPU info available", Toast.LENGTH_SHORT).show()
            return
        }
        val labels  = cpus.map { formatCpuRow(it) }.toTypedArray()
        val checked = BooleanArray(cpus.size) { i ->
            ((cpuMask shr cpus[i].index) and 1L) == 1L
        }
        AlertDialog.Builder(this)
            .setTitle("Core Affinity")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton("OK") { _, _ ->
                var m = 0L
                for (i in cpus.indices)
                    if (checked[i]) m = m or (1L shl cpus[i].index)
                cpuMask = m
                saveSettings()
                val msg = if (m == 0L) "Core Affinity: Auto"
                          else "Core Affinity: " + cpus
                              .filter { ((m shr it.index) and 1L) == 1L }
                              .joinToString(", ") { "cpu${it.index}" }
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Auto") { _, _ ->
                cpuMask = 0L
                saveSettings()
                Toast.makeText(this, "Core Affinity: Auto", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // --- Background dialog: custom RGB / Hue-Sat-Lum colour + profiles + image ----
    // No presets. The user dials in a colour with R,G,B and Hue/Sat/Lum text boxes
    // (the two groups stay in sync), names + saves it as a profile, and can export
    // a profile to a file to carry to another device. "I want an Image!" picks a
    // .png/.jpg to use as the playback background instead of a solid colour.
    //
    // Colours are stored in PFA BGR format (R=bit0, G=bit8, B=bit16). The Hue/Sat/
    // Lum fields use PFA's exact HSV maths (PFA labels Value "Lum"); see Misc.cpp.

    // PFA Util::RGBtoHSV (Misc.cpp:200). Returns H 0..359, S/V 0..100.
    private fun rgbToHsv(R: Int, G: Int, B: Int): Triple<Int, Int, Int> {
        val dR = R / 255.0; val dG = G / 255.0; val dB = B / 255.0
        val M = maxOf(dR, dG, dB); val m = minOf(dR, dG, dB); val C = M - m
        var dH = when {
            C == 0.0 -> 0.0
            M == dR  -> (dG - dB) / C
            M == dG  -> (dB - dR) / C + 2.0
            else     -> (dR - dG) / C + 4.0
        }
        if (dH < 0) dH += 6.0
        val dV = M; val dS = if (dV > 0.0) C / dV else 0.0
        return Triple(((dH * 60.0 + 0.5).toInt()) % 360,
                      (dS * 100.0 + 0.5).toInt(),
                      (dV * 100.0 + 0.5).toInt())
    }

    // PFA Util::HSVtoRGB (Misc.cpp:220). H 0..359, S/V 0..100 -> R,G,B 0..255.
    private fun hsvToRgb(H: Int, S: Int, V: Int): Triple<Int, Int, Int> {
        val dH = H / 60.0; val dS = S / 100.0; val dV = V / 100.0
        val C = dV * dS; val mm = dV - C
        var r1 = 0.0; var g1 = 0.0; var b1 = 0.0
        when {
            dH < 1.0 -> { r1 = C;               g1 = C * dH;        b1 = 0.0 }
            dH < 2.0 -> { r1 = C * (2.0 - dH);  g1 = C;             b1 = 0.0 }
            dH < 3.0 -> { r1 = 0.0;             g1 = C;             b1 = C * (dH - 2.0) }
            dH < 4.0 -> { r1 = 0.0;             g1 = C * (4.0 - dH); b1 = C }
            dH < 5.0 -> { r1 = C * (dH - 4.0);  g1 = 0.0;           b1 = C }
            else     -> { r1 = C;               g1 = 0.0;           b1 = C * (6.0 - dH) }
        }
        return Triple(((r1 + mm) * 255.0 + 0.5).toInt(),
                      ((g1 + mm) * 255.0 + 0.5).toInt(),
                      ((b1 + mm) * 255.0 + 0.5).toInt())
    }

    private fun showBgColorDialog() {
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT
        val mp = ViewGroup.LayoutParams.MATCH_PARENT

        // Current colour seeds the fields.
        var R = bgColor and 0xFF
        var G = (bgColor shr 8) and 0xFF
        var B = (bgColor shr 16) and 0xFF

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(4))
        }
        val swatch = View(this)
        root.addView(swatch, LinearLayout.LayoutParams(mp, dp(40)))
        root.addView(dialogLabel("Tap the colour above to apply it (switches off any image)").apply {
            textSize = 12f
        }, LinearLayout.LayoutParams(mp, wc).apply { bottomMargin = dp(12) })

        val rEt = colorField(); val gEt = colorField(); val bEt = colorField()
        val hEt = colorField(); val sEt = colorField(); val lEt = colorField()
        root.addView(colorRow("R", rEt, "G", gEt, "B", bEt))
        root.addView(colorRow("Hue", hEt, "Sat", sEt, "Lum", lEt))

        val restoreBtn = gloss(Button(this)).apply { text = "Restore to Default (PFA Grey)" }
        root.addView(restoreBtn, LinearLayout.LayoutParams(mp, wc).apply { topMargin = dp(8) })

        var updating = false
        fun applySwatch() = swatch.setBackgroundColor(Color.rgb(R, G, B))
        fun pushRgb() { updating = true; rEt.setText(R.toString()); gEt.setText(G.toString()); bEt.setText(B.toString()); updating = false }
        fun pushHsv() { val (h, s, v) = rgbToHsv(R, G, B); updating = true; hEt.setText(h.toString()); sEt.setText(s.toString()); lEt.setText(v.toString()); updating = false }
        // Commit the current R,G,B as the solid background, dropping any image.
        fun commitColor() {
            bgColor = (R and 0xFF) or ((G and 0xFF) shl 8) or ((B and 0xFF) shl 16)
            bgImagePath = null            // picking a colour drops any image
            saveSettings()
            toast("Background colour set")
        }

        val onRgb = {
            R = clampField(rEt, 0, 255); G = clampField(gEt, 0, 255); B = clampField(bEt, 0, 255)
            pushHsv(); applySwatch()
        }
        val onHsv = {
            val (nr, ng, nb) = hsvToRgb(clampField(hEt, 0, 359), clampField(sEt, 0, 100), clampField(lEt, 0, 100))
            R = nr; G = ng; B = nb; pushRgb(); applySwatch()
        }
        for (e in listOf(rEt, gEt, bEt)) watch(e) { if (!updating) onRgb() }
        for (e in listOf(hEt, sEt, lEt)) watch(e) { if (!updating) onHsv() }
        pushRgb(); pushHsv(); applySwatch()

        // --- profile name + buttons ---
        val nameEt = EditText(this).apply {
            hint = "Profile name"; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        root.addView(dialogLabel("Save this colour as a named profile:"),
            LinearLayout.LayoutParams(mp, wc).apply { topMargin = dp(8) })
        root.addView(nameEt)

        root.addView(gloss(Button(this)).apply {
            text = "Save Profile"
            setOnClickListener {
                val nm = nameEt.text.toString().trim()
                if (nm.isEmpty()) { toast("Enter a profile name first"); return@setOnClickListener }
                saveProfile(nm, R, G, B); toast("Saved profile \"$nm\"")
            }
        }, LinearLayout.LayoutParams(mp, wc).apply { topMargin = dp(4) })

        val applyColor: (Int, Int, Int) -> Unit = { r, g, b -> R = r; G = g; B = b; pushRgb(); pushHsv(); applySwatch() }
        root.addView(gloss(Button(this)).apply {
            text = "Load Profile"
            setOnClickListener { showLoadProfileDialog(applyColor) }
        }, LinearLayout.LayoutParams(mp, wc))
        root.addView(gloss(Button(this)).apply {
            text = "Export Profile to File"
            setOnClickListener { showExportProfileDialog() }
        }, LinearLayout.LayoutParams(mp, wc))

        val imageBtn = gloss(Button(this)).apply { text = "I want an Image!" }
        root.addView(imageBtn, LinearLayout.LayoutParams(mp, wc).apply { topMargin = dp(8) })

        val scroll = ScrollView(this).apply { addView(root) }
        // Always dark: every label and field in here is drawn white. Through
        // UiTheme so the themed constructor (API 11) and the theme ids (21/14)
        // are only touched where they exist — the old direct call was a crash
        // on 2.3 and an unknown theme id before 5.1.
        val dlg = UiTheme.dialogBuilder(this, true)
            .setTitle("Background")
            .setView(scroll)
            .setPositiveButton("Apply Colour") { _, _ -> commitColor() }
            .setNegativeButton("Cancel", null)
            .create()
        // Tapping the swatch applies the current colour and closes — the quick way
        // to swap an image back for a solid colour.
        swatch.setOnClickListener { commitColor(); dlg.dismiss() }
        // Restore the standard PFA grey (0x464646) and apply it immediately.
        restoreBtn.setOnClickListener {
            R = 0x46; G = 0x46; B = 0x46
            pushRgb(); pushHsv(); applySwatch()
            commitColor(); dlg.dismiss()
        }
        imageBtn.setOnClickListener { dlg.dismiss(); pickFile(REQ_BG_IMAGE) }
        dlg.show()
    }

    // --- colour-dialog view helpers ---

    private fun colorField(): EditText = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER
        textSize = 16f
        setTextColor(Color.WHITE)
        setSelectAllOnFocus(true)
    }

    private fun dialogLabel(text: String): TextView = TextView(this).apply {
        this.text = text; setTextColor(Color.WHITE); textSize = 14f
    }

    private fun colorRow(l1: String, e1: EditText, l2: String, e2: EditText,
                         l3: String, e3: EditText): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun cell(lbl: String, et: EditText) {
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(dialogLabel(lbl))
            col.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = dp(8)        // marginEnd is API 17; aPFA lays out LTR
            })
        }
        cell(l1, e1); cell(l2, e2); cell(l3, e3)
        return row
    }

    private fun watch(et: EditText, onChange: () -> Unit) {
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = onChange()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }

    private fun clampField(et: EditText, lo: Int, hi: Int): Int =
        (et.text.toString().toIntOrNull() ?: lo).coerceIn(lo, hi)

    // --- colour profiles (stored as JSON in SharedPreferences) -------------------

    private fun loadProfiles(): JSONArray = try {
        JSONArray(getPreferences(MODE_PRIVATE).getString("colorProfiles", "[]"))
    } catch (e: Exception) { JSONArray() }

    private fun profileJson(name: String, R: Int, G: Int, B: Int): JSONObject {
        val (h, s, v) = rgbToHsv(R, G, B)
        return JSONObject().apply {
            put("name", name); put("r", R); put("g", G); put("b", B)
            put("hue", h); put("sat", s); put("lum", v)
        }
    }

    private fun saveProfile(name: String, R: Int, G: Int, B: Int) {
        val arr = loadProfiles(); val out = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("name") != name) out.put(o)   // replace same-named
        }
        out.put(profileJson(name, R, G, B))
        getPreferences(MODE_PRIVATE).edit().putString("colorProfiles", out.toString()).apply()
    }

    private fun showLoadProfileDialog(onPick: (Int, Int, Int) -> Unit) {
        val arr = loadProfiles()
        val items = ArrayList<String>().apply {
            add("Import from file…")
            for (i in 0 until arr.length()) add(arr.getJSONObject(i).optString("name"))
        }
        AlertDialog.Builder(this)
            .setTitle("Load Profile")
            .setItems(items.toTypedArray()) { _, which ->
                if (which == 0) { pickFile(REQ_IMPORT_PROFILE); return@setItems }
                val o = arr.getJSONObject(which - 1)
                onPick(o.optInt("r"), o.optInt("g"), o.optInt("b"))
                toast("Loaded \"${o.optString("name")}\"")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showExportProfileDialog() {
        val arr = loadProfiles()
        if (arr.length() == 0) { toast("No saved profiles to export"); return }
        val names = Array(arr.length()) { arr.getJSONObject(it).optString("name") }
        AlertDialog.Builder(this)
            .setTitle("Export Profile to File")
            .setItems(names) { _, which ->
                pendingExport = arr.getJSONObject(which)
                pendingExportFile = names[which] + ".apfacolor.json"
                // aPFA's browser in save mode, like every other pick.
                openBrowser(REQ_EXPORT_PROFILE)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // --- settings persistence ---

    private fun loadSettings() {
        val p = getPreferences(MODE_PRIVATE)
        voiceCount = p.getInt("voiceCount", voiceCount)
        noteSpeed  = p.getFloat("noteSpeed", noteSpeed)
        cpuMask    = p.getLong("cpuMask", cpuMask)
        legacyRenderer = p.getBoolean("legacyRenderer", legacyRenderer)
        chunkedStreaming = p.getBoolean("diskStreaming", chunkedStreaming)
        sdPagefile = p.getBoolean("sdPagefile", sdPagefile)
        synthVolume = p.getInt("synthVolume", synthVolume).coerceIn(0, 100)
        sampleRate = p.getInt("sampleRate", sampleRate).takeIf { it in SAMPLE_RATES }
                     ?: DEFAULT_SAMPLE_RATE
        resW       = p.getInt("resW", resW)
        resH       = p.getInt("resH", resH)
        verboseLoading  = p.getBoolean("verboseLoading", verboseLoading)
        startFullscreen = p.getBoolean("startFullscreen", startFullscreen)
        pauseOnLoad     = p.getBoolean("pauseOnLoad", pauseOnLoad)
        // themeMode is read in onCreate, ahead of setTheme().
        bgColor    = p.getInt("bgColor", bgColor)
        bgImagePath = p.getString("bgImage", null)?.takeIf { File(it).exists() }
        // The saved soundfont is ALWAYS restored. This used to be dropped for
        // good whenever its content URI didn't open at launch — but that
        // fails for reasons that say nothing about the file: a grant evicted
        // by Android's per-app cap (every MIDI played used to take one, so
        // the soundfont's, being the oldest, went first), a card or provider
        // not ready yet at cold start, or a GET_CONTENT pick that never had
        // a persistable grant. Playback reaches it by path first anyway
        // (PlaybackActivity.prepareSoundfont), so only a real absence matters,
        // and that is reported by warnIfSoundfontMissing() instead.
        p.getString("soundfont", null)?.let { saved ->
            soundfontUri = Uri.parse(saved)
            soundfontName = p.getString("soundfontName", null)
        }
    }

    private fun isReadable(uri: Uri): Boolean = try {
        contentResolver.openFileDescriptor(uri, "r")?.close() != null
    } catch (e: Exception) {
        false
    }

    private fun saveSettings() {
        getPreferences(MODE_PRIVATE).edit()
            .putInt("voiceCount", voiceCount)
            .putFloat("noteSpeed", noteSpeed)
            .putLong("cpuMask", cpuMask)
            .putBoolean("legacyRenderer", legacyRenderer)
            .putBoolean("diskStreaming", chunkedStreaming)
            .putBoolean("sdPagefile", sdPagefile)
            .putInt("synthVolume", synthVolume)
            .putInt("sampleRate", sampleRate)
            .putInt("resW", resW)
            .putInt("resH", resH)
            .putInt("themeMode", themeMode)
            .putBoolean("verboseLoading", verboseLoading)
            .putBoolean("startFullscreen", startFullscreen)
            .putBoolean("pauseOnLoad", pauseOnLoad)
            .putInt("bgColor", bgColor)
            .putString("bgImage", bgImagePath)
            .putString("soundfont", soundfontUri?.toString())
            .putString("soundfontName", soundfontName)
            .apply()
    }

    // --- helpers ---

    // Panel labels sit straight on the (always dark) wallpaper now that the
    // box is gone, so they read like the byline in either mode.
    private fun label(text: String): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(Color.WHITE)
        tv.setShadowLayer(4f, 0f, 2f, Color.BLACK)
        tv.textSize = 15f
        return tv
    }

    private fun gloss(b: Button): Button = UiTheme.gloss(b, dark)

    private fun simpleListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) = onChange(progress)
        override fun onStartTrackingTouch(sb: SeekBar?) {}
        override fun onStopTrackingTouch(sb: SeekBar?) { saveSettings() }
    }

    private fun loadAsset(name: String): Bitmap? = try {
        assets.open(name).use { BitmapFactory.decodeStream(it) }
    } catch (e: Exception) {
        null
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun appVersion(): String =
        packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0.0"

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // Getting a file out of the device.
    //
    // Every open — MIDI, soundfont, background image, colour profile — goes to
    // aPFA's own browser (FileBrowserActivity) in place of the system picker:
    // it shows only what aPFA can open, with sizes, remembers the folder per
    // kind, and looks like the rest of the app on every version down to 2.3.
    //
    // The system picker survives only as the way out when All files access is
    // declined (systemPick, below), best first:
    //
    //   1. ACTION_OPEN_DOCUMENT (SAF, API 19+).
    //   2. ACTION_GET_CONTENT. What third-party managers (Total Commander, ES,
    //      ZArchiver) actually register for — almost none of them implement a
    //      DocumentsProvider, so they never show up for step 1.
    //
    // Both are probed before firing: Fire OS ships no DocumentsUI, and an
    // unhandled startActivity throws ActivityNotFoundException, which used to
    // kill the app outright the moment you pressed Load Soundfont.
    private fun pickFile(requestCode: Int) = openBrowser(requestCode)

    /** Steps 1 and 2 above; false when the device has neither. */
    private fun systemPick(requestCode: Int, mime: String = "*/*"): Boolean {
        // Export is a save: the system's version is SAF's create-document
        // dialog (API 19+; there is no GET_CONTENT equivalent).
        if (requestCode == REQ_EXPORT_PROFILE) {
            if (Build.VERSION.SDK_INT < 19) return false
            return startPicker(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/json"
                putExtra(Intent.EXTRA_TITLE, pendingExportFile)
            }, requestCode)
        }
        if (Build.VERSION.SDK_INT >= 19 &&
            startPicker(pickerIntent(Intent.ACTION_OPEN_DOCUMENT, mime), requestCode)) return true
        return startPicker(pickerIntent(Intent.ACTION_GET_CONTENT, mime), requestCode)
    }

    private fun pickerIntent(action: String, mime: String): Intent =
        Intent(action).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
        }

    /**
     * Fire a picker intent, reporting false instead of crashing when nothing on
     * the device handles it.
     *
     * resolveActivity() is checked first and the throw caught second on purpose:
     * the query can report a handler that then refuses the start, and on a
     * stripped ROM it can equally report nothing at all. Either way this is the
     * exact call that was taking the app down on Fire OS, so it gets both.
     */
    private fun startPicker(intent: Intent, requestCode: Int): Boolean {
        if (packageManager.resolveActivity(intent, 0) == null) return false
        return try {
            startActivityForResult(intent, requestCode)
            true
        } catch (e: Exception) {
            Log.w("aPFA", "picker: no handler for ${intent.action}", e)
            false
        }
    }

    private fun extensionsFor(requestCode: Int): Array<String> = when (requestCode) {
        REQ_MIDI           -> arrayOf("mid", "midi")
        REQ_SOUNDFONT      -> arrayOf("sf2", "sf3", "sfz")
        REQ_BG_IMAGE       -> arrayOf("png", "jpg", "jpeg")
        REQ_IMPORT_PROFILE, REQ_EXPORT_PROFILE -> arrayOf("json")
        else -> emptyArray()
    }

    private fun browserTitle(requestCode: Int): String = when (requestCode) {
        REQ_MIDI           -> "Choose a MIDI/Black MIDI (.mid)"
        REQ_SOUNDFONT      -> "Choose a Soundfont (.sf2/.sf3/.sfz)"
        REQ_BG_IMAGE       -> "Choose an Image (.png/.jpg)"
        REQ_IMPORT_PROFILE -> "Choose a Colour Profile (.json)"
        REQ_EXPORT_PROFILE -> "Export Profile (.json)"
        else               -> "Choose a file"
    }

    // --- aPFA's file browser ---
    //
    // It reads storage directly, which from API 30 means "All files access":
    // scoped storage makes listFiles() on /sdcard come back empty or null
    // whatever READ_EXTERNAL_STORAGE says. aPFA ships sideloaded, so asking is
    // fine; refusing falls back to the system picker for this session.

    // The pick waiting on the All-files-access screen.
    private var pendingBrowserRequest = 0
    // Chose "Use system picker" this session — don't ask again until relaunch.
    private var declinedAllFiles = false

    private fun openBrowser(requestCode: Int) {
        if (Build.VERSION.SDK_INT >= 30 && !hasAllFilesAccess()) {
            if (declinedAllFiles && systemPick(requestCode)) return
            pendingBrowserRequest = requestCode
            promptAllFilesAccess()
            return
        }
        startBrowser(requestCode)
    }

    private fun startBrowser(requestCode: Int) {
        val intent = Intent(this, FileBrowserActivity::class.java)
        intent.putExtra(FileBrowserActivity.EXTRA_TITLE, browserTitle(requestCode))
        intent.putExtra(FileBrowserActivity.EXTRA_EXTENSIONS, extensionsFor(requestCode))
        intent.putExtra(FileBrowserActivity.EXTRA_KIND, requestCode.toString())
        intent.putExtra(FileBrowserActivity.EXTRA_DARK, dark)
        if (requestCode == REQ_EXPORT_PROFILE)
            intent.putExtra(FileBrowserActivity.EXTRA_SAVE_NAME, pendingExportFile)
        startActivityForResult(intent, requestCode)
    }

    /**
     * Isolated in its own method because Environment.isExternalStorageManager()
     * is API 30 and this app still runs on Dalvik at API 10, where resolving a
     * missing member can poison the whole enclosing method at verify time. Only
     * ever called behind an SDK_INT gate, so old runtimes never verify it.
     */
    @TargetApi(30)
    private fun hasAllFilesAccess(): Boolean =
        try { Environment.isExternalStorageManager() } catch (e: Throwable) { false }

    private fun promptAllFilesAccess() {
        val request = pendingBrowserRequest
        AlertDialog.Builder(this)
            .setTitle("Storage access needed")
            .setMessage("aPFA's file browser reads your storage directly, so it can " +
                        "show only the files aPFA can open, with their sizes.\n\n" +
                        "Android 11 and up only allows that with \"All files access\". " +
                        "Turn it on for aPFA on the next screen, then press Back.")
            .setPositiveButton("Continue") { _, _ ->
                if (!startAllFilesSettings()) startBrowser(request)
            }
            .setNegativeButton("Use system picker") { _, _ ->
                declinedAllFiles = true
                // No picker at all (Fire OS): browse what is still visible.
                if (!systemPick(request)) startBrowser(request)
            }
            .show()
    }

    /**
     * Open the All-files-access screen. Those two action strings are API 30
     * constants, so they inline at compile time and are harmless on older
     * runtimes. The per-app screen is missing on some builds, hence the fall
     * back to the global list and then to browsing whatever is still visible.
     */
    private fun startAllFilesSettings(): Boolean {
        val perApp = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:$packageName"))
        val global = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
        for (intent in arrayOf(perApp, global)) {
            if (packageManager.resolveActivity(intent, 0) == null) continue
            try {
                startActivityForResult(intent, REQ_ALL_FILES_PERM)
                return true
            } catch (e: Exception) {
                Log.w("aPFA", "all-files: ${intent.action} not handled", e)
            }
        }
        toast("No all-files-access screen on this device")
        return false
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        // The all-files-access screen always reports CANCELED — the grant lands in
        // isExternalStorageManager(), never in the result — so this has to be
        // handled ahead of the RESULT_OK gate. Granted or not, open the browser:
        // without the grant it still shows aPFA's own folder.
        if (requestCode == REQ_ALL_FILES_PERM) {
            if (pendingBrowserRequest != 0) startBrowser(pendingBrowserRequest)
            pendingBrowserRequest = 0
            return
        }
        if (resultCode != RESULT_OK) return
        // aPFA's browser returns a path (see FileBrowserActivity), the system
        // pickers a content:// URI. file:// URIs read through contentResolver on
        // every API level and PlaybackActivity.resolveLocalPath() short-circuits
        // them to the raw path, so handlePicked() takes both unchanged.
        val uri = data?.data
            ?: data?.getStringExtra(FileBrowserActivity.EXTRA_PATH)?.let { Uri.fromFile(File(it)) }
            ?: return
        handlePicked(requestCode, uri)
    }

    private fun handlePicked(requestCode: Int, uri: Uri) {
        val name = displayName(uri).lowercase()
        when (requestCode) {
            REQ_MIDI -> {
                if (!name.endsWith(".mid") && !name.endsWith(".midi")) {
                    Toast.makeText(this, "Not a MIDI file (.mid)", Toast.LENGTH_SHORT).show()
                    return
                }
                // No persist(): a MIDI is played once, right now, on the
                // grant that came with the pick (handed on by the playback
                // intent). Persisting each one is what used to push the
                // soundfont's grant out of Android's per-app cap.
                midiUri = uri
                launchPlayback()
            }
            REQ_SOUNDFONT -> {
                if (!name.endsWith(".sf2") && !name.endsWith(".sf3") &&
                    !name.endsWith(".sfz")) {
                    Toast.makeText(this, "Not a soundfont (.sf2/.sf3/.sfz)",
                                   Toast.LENGTH_SHORT).show()
                    return
                }
                soundfontUri?.let { if (it != uri) release(it) }
                persist(uri)
                soundfontUri = uri
                soundfontName = displayName(uri)
                soundfontButton.text = sfButtonLabel(uri)
                saveSettings()        // remember it across launches
            }
            REQ_BG_IMAGE -> {
                if (!name.endsWith(".png") && !name.endsWith(".jpg") && !name.endsWith(".jpeg")) {
                    toast("Pick a .png or .jpg image")
                    return
                }
                // Copy into app storage so it survives the picker's transient grant.
                // BitmapFactory detects the format from content, so a fixed name is fine.
                val path = copyUriToFile(uri, "bg_image")
                if (path == null) { toast("Could not read that image"); return }
                bgImagePath = path
                saveSettings()
                toast("Background image set")
            }
            REQ_EXPORT_PROFILE -> {
                val json = pendingExport ?: return
                pendingExport = null
                try {
                    // "wt", not "w": several providers don't truncate on a bare
                    // "w", and replacing a longer file would leave its tail.
                    contentResolver.openOutputStream(uri, "wt")!!.use {
                        it.write(json.toString(2).toByteArray())
                    }
                    toast("Exported \"${json.optString("name")}\"")
                } catch (e: Exception) {
                    // A folder that listed fine can still refuse a write (a card
                    // root on 4.4+, a permission turned off since). The profile
                    // isn't lost: it goes where aPFA can always write.
                    Log.w("aPFA", "export to $uri failed", e)
                    pendingExport = json
                    exportToAppFolder(json.optString("name"),
                        "aPFA couldn't write to the folder you picked")
                }
            }
            REQ_IMPORT_PROFILE -> {
                try {
                    val text = contentResolver.openInputStream(uri)!!.use {
                        it.readBytes().toString(Charsets.UTF_8)
                    }
                    val o = JSONObject(text)
                    val nm = o.optString("name").ifEmpty { "Imported" }
                    saveProfile(nm, o.getInt("r"), o.getInt("g"), o.getInt("b"))
                    toast("Imported \"$nm\" — open Load Profile to use it")
                } catch (e: Exception) {
                    toast("Not a valid colour profile file")
                }
            }
        }
    }

    /** Last-resort export: aPFA's own external folder, which needs no permission. */
    private fun exportToAppFolder(name: String, why: String) {
        val json = pendingExport ?: return
        pendingExport = null
        val safe = name.filter { it.isLetterOrDigit() || it == '-' || it == '_' || it == ' ' }.trim()
        val out = File(getExternalFilesDir(null) ?: filesDir,
                       (if (safe.isEmpty()) "profile" else safe) + ".apfacolor.json")
        try {
            FileOutputStream(out).use { it.write(json.toString(2).toByteArray()) }
            AlertDialog.Builder(this)
                .setTitle("Exported")
                .setMessage("$why, so the profile was written to:\n\n${out.absolutePath}")
                .setPositiveButton("OK", null)
                .show()
        } catch (e: Exception) {
            toast("Export failed")
        }
    }

    private fun copyUriToFile(uri: Uri, outName: String): String? = try {
        val out = File(filesDir, outName)
        contentResolver.openInputStream(uri)!!.use { input ->
            FileOutputStream(out).use { output -> input.copyTo(output, 1 shl 16) }
        }
        out.absolutePath
    } catch (e: Exception) {
        null
    }

    /** Give back a persisted grant aPFA no longer needs (API 19+, like persist). */
    private fun release(uri: Uri) {
        if (Build.VERSION.SDK_INT < 19) return
        try {
            contentResolver.releasePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            // never held, or already gone
        }
    }

    /**
     * Drop every persisted grant except the soundfont's. Clears out the
     * per-MIDI grants earlier versions took, which is what was crowding the
     * soundfont's own grant out of Android's cap (128, or 512 from Android 11).
     */
    private fun pruneGrants() {
        if (Build.VERSION.SDK_INT < 19) return
        try {
            for (perm in contentResolver.persistedUriPermissions)
                if (perm.uri != soundfontUri) release(perm.uri)
        } catch (e: Exception) {
            Log.w("aPFA", "grant prune failed", e)
        }
    }

    /**
     * Say so, once per launch, when the saved soundfont really can't be
     * reached — neither through its URI nor at its path — instead of quietly
     * forgetting it. The setting is kept either way: the card may come back.
     */
    private fun warnIfSoundfontMissing() {
        val uri = soundfontUri ?: return
        if (isReadable(uri)) return
        val path = PlaybackActivity.resolveLocalPath(uri)
        if (path != null && File(path).canRead()) return
        toast("Can't open the saved soundfont" +
              (soundfontName?.let { " ($it)" } ?: "") +
              " right now. If playback is silent, load it again.")
    }

    private fun persist(uri: Uri) {
        // takePersistableUriPermission is API 19+ — calling it below that is a
        // NoSuchMethodError (not an Exception, so the catch won't save us). The
        // browser's file:// URIs need no grant anyway.
        if (Build.VERSION.SDK_INT < 19) return
        try {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            // the in-session grant still applies — fine for this launch
        }
    }

    private fun launchPlayback() {
        val midi = midiUri ?: return
        saveSettings()
        // The scan runs on every return to this screen (onResume). The clock
        // cap is the one warning re-armed per playback: the run just finished
        // is what heats the phone, so a cap still live afterwards — with that
        // run's temperature — is news every time, not a repeat.
        playedThisProcess = true
        perfWarned.remove("clockcap")
        val intent = Intent(this, PlaybackActivity::class.java)
        intent.putExtra(PlaybackActivity.EXTRA_MIDI, midi.toString())
        soundfontUri?.let { intent.putExtra(PlaybackActivity.EXTRA_SF, it.toString()) }
        intent.putExtra(PlaybackActivity.EXTRA_VOICES, voiceCount)
        intent.putExtra(PlaybackActivity.EXTRA_SPEED, noteSpeed)
        intent.putExtra(PlaybackActivity.EXTRA_CPU_MASK, cpuMask)
        intent.putExtra(PlaybackActivity.EXTRA_LEGACY, legacyRenderer)
        intent.putExtra(PlaybackActivity.EXTRA_STREAM, chunkedStreaming)
        // Pass the intent, not a path: the card can be pulled between here and
        // the load, so PlaybackActivity resolves the directory fresh.
        intent.putExtra(PlaybackActivity.EXTRA_SD_POOL, sdPagefile)
        intent.putExtra(PlaybackActivity.EXTRA_SYNTH_VOLUME, synthVolume)
        intent.putExtra(PlaybackActivity.EXTRA_SAMPLE_RATE, sampleRate)
        intent.putExtra(PlaybackActivity.EXTRA_RES_W, resW)
        intent.putExtra(PlaybackActivity.EXTRA_RES_H, resH)
        intent.putExtra(PlaybackActivity.EXTRA_DARK, dark)
        intent.putExtra(PlaybackActivity.EXTRA_VERBOSE, verboseLoading)
        intent.putExtra(PlaybackActivity.EXTRA_START_FULLSCREEN, startFullscreen)
        intent.putExtra(PlaybackActivity.EXTRA_PAUSE_ON_LOAD, pauseOnLoad)
        intent.putExtra(PlaybackActivity.EXTRA_BG_COLOR, bgColor)
        bgImagePath?.let { intent.putExtra(PlaybackActivity.EXTRA_BG_IMAGE, it) }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(intent)
    }

    /**
     * "SF: <name>", cut down to whatever fits beside the settings panel.
     *
     * The button is anchored mid-left and grows rightward with its text, while
     * the Voice Count / Note Speed panel is pinned bottom-right — so a long
     * soundfont name runs straight underneath it. Where "too long" starts is a
     * per-resolution question: a 2340px-wide S22U swallows most names whole,
     * a 1280px-wide Stylo 3 collides after roughly half of one. So the limit is
     * the real gap between the two, measured on this display, and a name past
     * it gets cut with a trailing "...".
     */
    private fun sfButtonLabel(uri: Uri): String {
        // Both activities are locked landscape, but the metrics can still be
        // read portrait-side-up during the first onCreate — and configChanges
        // swallows the rotation, so buildSetupScreen() never runs again to fix
        // it. Take the long edge, which is the landscape width either way.
        val m = resources.displayMetrics
        val screenW = if (m.widthPixels > m.heightPixels) m.widthPixels else m.heightPixels
        val budget = (screenW
                      - dp(EDGE_MARGIN_DP)                        // the button's own left margin
                      - dp(PANEL_WIDTH_DP)                        // panel, flush to the corner
                      - dp(SF_GAP_DP)
                      - soundfontButton.paddingLeft
                      - soundfontButton.paddingRight).toFloat()
        return SF_PREFIX + truncateToWidth(soundfontName ?: displayName(uri), budget)
    }

    /** Longest head of [name] whose label still measures under [budgetPx]. */
    private fun truncateToWidth(name: String, budgetPx: Float): String {
        if (labelWidth(SF_PREFIX + name) <= budgetPx) return name
        var end = name.length
        while (end > 0 &&
               labelWidth(SF_PREFIX + name.substring(0, end) + SF_ELLIPSIS) > budgetPx) {
            end--
        }
        // Trailing space before the "..." only looks like a mistake.
        return name.substring(0, end).trimEnd() + SF_ELLIPSIS
    }

    // Buttons draw all-caps under the Material themes, and caps are wider than
    // the name measures raw — so measure the text as it will actually be drawn.
    private fun labelWidth(text: String): Float {
        val shown = soundfontButton.transformationMethod
            ?.getTransformation(text, soundfontButton) ?: text
        return soundfontButton.paint.measureText(shown.toString())
    }

    private fun displayName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "file"
        try {
            // Closed by hand: Cursor is only Closeable from API 16, so .use{}
            // throws IncompatibleClassChangeError (an Error, past the catch)
            // on anything older.
            val c = contentResolver.query(uri, null, null, null, null)
            if (c != null) try {
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) name = c.getString(idx)
                }
            } finally {
                c.close()
            }
        } catch (e: Exception) {
            // keep the path-segment fallback
        }
        return name
    }
}
