// synth.h — BASS + BASSMIDI wrapper, fed from a dedicated feeder thread.
//
// noteOn/noteOff/sendRaw pack the raw 3-byte MIDI message into a bounded
// single-producer ring and return. A feeder thread drains it IN ORDER and makes
// one BASS_MIDI_StreamEvents(BASS_MIDI_EVENTS_RAW) call per event — still one
// call per event, never batched (APFA-DESIGN.md §4, PFA-ANALYSIS.md §5).
//
// This is OmniMIDI's split, which is what PFA actually runs against: PFA's
// SendDirectData only writes one DWORD into OmniMIDI's EVBuffer
// (BufferSystem.h ParseData) and OmniMIDI's EventsProcesser thread makes the
// BASS call. Calling BASS on the engine thread charged the engine for
// OmniMIDI's half of the work: BASS's stream lock and its own clock read on
// every event, ~30% of the engine thread in Toilet Story 3's 1:55+ frame on the
// S22 Ultra (TS3-CPU-PREMISES-FINDINGS-2026-10-21.md).
//
// The feeder is OmniMIDI's thread, so like OmniMIDI's it gets a core of its
// own. With ONE core selected the engine keeps that core to itself and the
// feeder runs elsewhere. Making the calls on the engine thread instead put
// both halves on one core and cost 49 s on TS3: 155 s of BASS calls against
// 43 s of waiting on the feeder (findings §9). With several cores selected the
// feeder is kept on them (feederTidFor), so the user chooses its core too.
#pragma once

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <thread>

#include "bassmidi.h"

namespace apfa {

class Synth {
public:
    // sampleRate is what BASSMIDI renders at; the output device stays at
    // kDeviceRate and BASS resamples, so any rate down to 4 kHz plays.
    // volume is BASS_ATTRIB_VOL (0..1), applied after the limiter.
    bool init(int voiceLimit, int sampleRate = 44100, float volume = 1.0f);
    bool loadSoundfont(const std::string& path);
    void setVoiceLimit(int voices);
    void start(uint64_t reservedMask = 0);
    void pause();
    void resume();
    void allNotesOff();
    // Release every sounding note without touching pitch bend — PFA's
    // MIDIOutDevice::AllNotesOff. This is what pause() uses.
    void releaseAllNotes();

    void noteOn(int channel, int key, int velocity);
    void noteOff(int channel, int key);
    void flush();   // no-op, kept for call-site compat

    // calls/micros: BASS calls the feeder made and the (sampled) time they
    // took. bpMicros: time the engine spent blocked on a full feeder ring.
    void sampleEventCost(uint64_t& calls, uint64_t& micros, uint64_t& bpMicros);
    // Voices actually sounding right now vs the ceiling the guard may lower to.
    // For the perf log only — nothing in the engine reads these.
    void sampleGuard(int& voiceCeiling, int& voiceFloorSeen);

    bool ready() const { return ready_; }
    void shutdown();

    void sendRaw(uint8_t status, uint8_t d1, uint8_t d2);

    // The feeder's tid if `mask` selects several cores, so the caller can keep
    // the feeder on them; 0 for one core (the feeder then stays off it) or if
    // the tid is unknown.
    long feederTidFor(uint64_t mask);

private:
    // --- audio overload guard -----------------------------------------------
    // BASSMIDI on a slow SoC can need MORE than real time to render a dense
    // Black MIDI: measured 100-127% render load on an SD425, which drains the
    // playback buffer to nothing and makes the audio stutter. Lowering the
    // voice count fixes it, which is why this is the one thing users were
    // being told to do by hand.
    //
    // This is the OmniMIDI analog. OmniMIDI caps its own render load with
    // BASSMIDI's built-in BASS_ATTRIB_MIDI_CPU (BASSSynth.cpp: MaxCPU = 95),
    // which makes BASSMIDI shed voices to stay under the limit. That attribute
    // is set here too, but it did not engage on this BASSMIDI build (2.4.16,
    // Android) - the voice count stayed pinned at the limit while the render
    // load sat at 126%. So the same policy is applied from the outside: a low
    // rate guard thread watches the playback buffer and the render load and
    // moves BASS_ATTRIB_MIDI_VOICES between a floor and the user's setting.
    //
    // This is deliberately AUDIO ONLY. The clock, dispatch, the active-note
    // set, the note count and everything drawn are untouched, so the real-time
    // slowdown that the engine is built around is unaffected - only how many
    // voices sound at once adapts, exactly as OmniMIDI does on the desktop.
    void guardMain();
    void startGuard();
    void stopGuard();

    std::thread       guardThread_;
    std::atomic<bool> guardRun_{false};
    // Set false whenever the buffer has to refill from empty (start, resume,
    // seek): a filling buffer reads as a starving one and would otherwise slam
    // the voice count on the first frame.
    std::atomic<bool> guardArmed_{false};
    std::atomic<int>  voiceCeiling_{250};   // the user's Voice Count setting
    std::atomic<int>  voiceCurrent_{250};   // what the guard has it set to now
    std::atomic<int>  voiceFloorSeen_{1 << 30};

    // --- feeder ---------------------------------------------------------------
    // Engine thread -> feeder thread, single producer / single consumer. The
    // engine only ever writes feedWrite_ and the feeder only feedRead_; each
    // side keeps a private copy of the other's index and re-reads the shared
    // one only when that copy says the ring is full (engine) or empty (feeder).
    //
    // When the ring is full the engine waits for room: PFA's midiOutShortMsg
    // blocks the same way when the synth cannot keep up, so back-pressure stays
    // faithful and engages only at genuine saturation. 64K events is ~25 ms of
    // a drained Toilet Story 3 frame — enough slack to ride out BASS's render
    // thread holding the stream lock, short enough that audio never trails the
    // picture by anything audible.
    void startFeeder();
    void stopFeeder();
    void feederMain();
    void wakeFeeder();
    void deliver(uint32_t msg);

    static constexpr uint64_t kFeedCap = 1u << 16;   // power of two
    std::unique_ptr<uint32_t[]> feedBuf_;
    std::thread             feederThread_;
    std::atomic<bool>       feederRun_{false};
    std::mutex              feedMutex_;
    std::condition_variable feedCv_;
    // Padded apart so the engine's stores and the feeder's stores do not
    // bounce one cache line between the two cores on every event.
    char                    feedPad0_[64];
    std::atomic<uint64_t>   feedWrite_{0};      // engine-owned
    uint64_t                feedReadCache_ = 0; // engine's copy of feedRead_
    char                    feedPad1_[64];
    std::atomic<uint64_t>   feedRead_{0};       // feeder-owned
    char                    feedPad2_[64];
    // Read by the engine on every push, written only when the feeder goes to
    // sleep or wakes — so it must not share a line with feedRead_.
    std::atomic<bool>       feederSleeping_{false};
    std::atomic<uint64_t>   bpNanos_{0};        // engine-owned, rarely written
    char                    feedPad3_[64];
    std::atomic<long>       feederTid_{0};

    HSTREAM    midiStream_ = 0;
    HSOUNDFONT font_       = 0;
    int  sampleRate_ = 44100;
    bool ready_      = false;

    std::atomic<uint64_t> evCalls_{0};
    std::atomic<uint64_t> evNanos_{0};   // sampled — see kEvTimeSampleEvery
};

}  // namespace apfa
